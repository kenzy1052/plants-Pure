# Plants & Pure redesign outcomes

## Premium brand direction

- Replace the former orange-led palette with a red-led system based on the supplied brand imagery and a warm ivory / charcoal foundation.
- Use the supplied Plants & Pure logo and real company product photos; do not generate or introduce AI imagery.
- Create an ultra-modern, premium editorial feel with fine rules, spacious layouts, and restrained motion.

## Homepage and hero

- Replace the old collage hero with a coherent company-led hero that communicates “Healthy living on the go!” and shows real pouch/bottle products.
- Add animated section reveals and subtle product hover motion while respecting reduced-motion preferences.
- Align home copy with the supplied company profile: Accra roots, quality, authenticity, trust, health & wellness, and innovation.

## Commerce experience

- Keep the existing catalogue/API, Supabase, cart, auth, checkout, Paystack and environment-variable boundaries unchanged.
- Make the homepage storefront lead naturally into the existing shop and product detail routes.
- Continue supporting live product data, search, filtering, add-to-cart, cart drawer, checkout and order tracking.

## Content and trust

- Surface the three product ranges: spices, herbs, and oils.
- Add quality proof and women’s entrepreneurship messaging from the company profile.
- Keep contact and story routes available for fuller company information.
