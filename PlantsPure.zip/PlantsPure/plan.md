# Plants & Pure redesign plan

## Scope

Refresh the existing TanStack Start storefront using only supplied Plants & Pure imagery. Preserve the existing Supabase catalogue, cart, auth, checkout, payment and environment-variable integrations. Do not modify API/server behavior.

## Design

- **Design movement:** editorial luxury pantry — quiet, high-contrast layouts with restrained red accents and product photography treated like a premium still-life.
- **Core principles:** real product proof, spacious hierarchy, tactile cards, and purposeful motion.
- **Color philosophy:** warm ivory and deep charcoal create an expensive gallery backdrop; the supplied brand red becomes the signature action color; muted sage is retained only as a supporting natural cue.
- **Layout paradigm:** asymmetrical editorial compositions, oversized type, split hero, horizontal product rail, and alternating story panels rather than repeated centered grids.
- **Signature elements:** red oval brand mark, numbered section labels, fine rules, and softly rounded product frames.
- **Interaction philosophy:** small, confident transitions; product cards lift subtly; sections reveal on scroll; CTA motion is directional and restrained.
- **Animation:** existing Reveal transitions plus hover scale, image pan, and page fade; respect reduced-motion preferences.
- **Typography:** Newsreader for high-contrast editorial headlines, Inter for UI/body, Caveat only for small handwritten accents where already present.
- **Brand essence:** quality spices, herbs and oils for healthy living on the go — authentic, warm, precise. Personality: grounded, premium, caring.
- **Brand voice:** direct, sensory, trustworthy. Example lines: “Real ingredients. Remarkable everyday flavour.” / “Packed with care in Accra.”

## Implementation

- Add supplied company images under `src/assets/company`.
- Rebuild the homepage hero, range navigation, product showcase, quality proof, story, and CTA using those assets.
- Update global tokens from orange to the supplied red-led palette.
- Keep the existing `/shop`, product detail, cart, checkout, auth, account, tracking, contact and about routes functional.
- Add a static route manifest for the current page routes.
