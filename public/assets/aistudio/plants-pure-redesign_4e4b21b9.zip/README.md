# Plants & Pure Limited — online store

Production e-commerce rebuild for [Plants & Pure Limited](https://www.plantsandpure.com) (Accra, Ghana: natural spices, herbs and oils).
Stack: Next.js 16 (App Router), React 19, TypeScript, Tailwind v4, Supabase (Postgres + Auth), Paystack, Cloudinary, Resend.

> **Status: Phase 1 of 9 complete (foundation).** The storefront UI is still the preliminary demo and is redesigned in Phases 2–3.
> Read [`docs/PHASE_1_REPORT.md`](docs/PHASE_1_REPORT.md) for what is verified, what is not, and what needs a business decision.

## Quick start

```bash
npm ci
cp .env.example .env.local        # then fill in real values (never commit this file)
npm run env:check                 # lists which integrations are configured (names only)
npm run dev                       # http://localhost:3000
```

## Commands

| Command | What it does |
|---|---|
| `npm run dev` / `build` / `start` | Next.js dev server / production build / serve the build |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run lint` | ESLint |
| `npm run test:unit` | Unit tests (no database or network needed) |
| `npm run test:db` | Database tests: migrations, RLS, payment state machine. **Needs** `TEST_DATABASE_URL` pointing at a scratch Postgres 15+ server (it creates and drops `pure_test_*` databases; never point it at production) |
| `npm test` | All of the above test suites |
| `npm run db:check` | Builds a throw-away database from the baseline + all migrations and reports errors |
| `npm run smoke` | Black-box checks against a running server (`npm run smoke -- http://localhost:3000`) |
| `npm run env:check` | `node --env-file=.env.local scripts/check-env.mjs` |

## Documentation

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — how the pieces fit, request flows, trust boundaries
- [`docs/ENVIRONMENT.md`](docs/ENVIRONMENT.md) — every variable, where to get it, Supabase dashboard settings
- [`docs/DATABASE.md`](docs/DATABASE.md) — schema, migrations workflow, RLS matrix, admin bootstrap, backups
- [`docs/INTEGRATIONS.md`](docs/INTEGRATIONS.md) — Paystack, Cloudinary, Resend, Supabase Auth behaviour and verification status
- [`docs/COSTS.md`](docs/COSTS.md) — free-tier limits and possible charges
- [`docs/DECISIONS.md`](docs/DECISIONS.md) — architecture decisions and the open questions for the business
- [`docs/AUDIT.md`](docs/AUDIT.md) — the Phase 1 audit of the inherited demo
- [`AGENTS.md`](AGENTS.md) — notes for AI coding agents working in this repo

## Ground rules

- The **database and server are authoritative** for prices, stock, totals and payment state. The browser never decides them.
- A payment is "paid" only after the **server verifies it with Paystack**. A redirect or query string is never proof.
- Business facts live in `src/lib/constants/business.ts`, each marked verified/unverified. Do not invent content.
- Secrets exist only in server-side code and `.env.local`. `.env*` is git-ignored except `.env.example`.
