# Redesign reference notes

## Foodo

Source: [https://foodo.framer.ai/](https://foodo.framer.ai/)

The review showed a food-focused brand introduction and prominent catalogue merchandising. The reference does not expose enough static text to verify its booking/contact form internals, so the implementation uses the brief's direction rather than claiming to reproduce those details. Plants & Pure applies the form inspiration through visible labels, grouped fields, select controls, validation, clear loading states, and provider-confirmed success feedback.

## Common Grounds

Source: [https://common-grounds.framer.website/](https://common-grounds.framer.website/)

The site introduces the business through concise operating facts, a first-person company story, specials, category discovery, and a natural progression from business identity to products and contact. Plants & Pure adapts this into an editorial homepage, verified company facts, a live catalogue, ingredient-category discovery, product knowledge, FAQs, and business enquiries. No unverified statistics or customer testimonials are borrowed.

## Resend Contacts API

Sources: [https://resend.com/docs/api-reference/contacts/create-contact](https://resend.com/docs/api-reference/contacts/create-contact) and [https://resend.com/docs/api-reference/contacts](https://resend.com/docs/api-reference/contacts)

The documented Create Contact endpoint is `POST https://api.resend.com/contacts`. It accepts an email and an `unsubscribed` flag; optional segment membership uses a `segments` array containing IDs. The newsletter route therefore requires explicit consent, adds only to a configured segment, and reports success only after a successful provider response.
