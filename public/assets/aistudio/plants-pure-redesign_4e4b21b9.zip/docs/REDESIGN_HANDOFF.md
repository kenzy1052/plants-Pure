# Plants & Pure redesign handoff

## Delivered in this working copy

- Rebuilt the homepage as a progressive brand and product story: the hero, company introduction, live catalogue categories and products, transparent checkout notes, editorial discovery, FAQs, wholesale CTA and newsletter.
- Added original ingredient still-life images, an isolated transparent cutout, compact WebP assets, subtle pointer parallax, reduced-motion support, and a forest / ivory / saffron palette with persistent dark mode.
- Added `/discover`, `/faqs`, `/wholesale` and `/policies/{delivery,returns,privacy,terms}`.
- Added a dedicated `/cart` page with quantity updates, removal, subtotal and checkout handoff; the existing drawer remains available.
- Extended the live shop with GHS minimum/maximum price and in-stock filters, applied inside the server-side catalogue query.
- Improved contact subject selection, added structured wholesale and product enquiry forms, and connected them to the existing contact endpoint so success is shown only after Resend confirms acceptance.
- Added a newsletter API that requires explicit consent, honeypot checks and rate limiting and registers a subscriber with Resend only when the dedicated segment is configured.
- Added authenticated customer order-history and order-detail routes. They filter by the signed-in user's ID and remain subject to Supabase RLS.
- Added an admin overview, orders workspace and order detail/fulfillment control on top of the existing admin APIs and role checks.
- Added the new public pages to the sitemap and kept policy and private pages out of indexing.

## Required owner setup before launch

1. Configure a newsletter-specific Resend segment and set `RESEND_NEWSLETTER_SEGMENT_ID`. Without the ID, newsletter submissions intentionally return “not available.” Configure the Resend key and verified sending domain for transactional enquiry e-mail as documented in `ENVIRONMENT.md`.
2. Supply and approve actual company policies: delivery areas, timelines and fees; returns, refunds and cancellations; terms of sale; and a full privacy notice including data retention and privacy-request instructions. The policy pages currently state plainly that approved text was not supplied; they are not legal policy drafts.
3. Confirm final copy for product handling, package sizes, bulk minimums/prices, wholesale availability, contact hours and the company's own sourcing/quality commitments. No unverified certifications, review quotes, supplier guarantees or health claims were added.
4. Add real product images/reviews and maintain accurate product attributes, stock and category content in the existing catalogue/admin area. The new atmospheric still-life images are editorial ingredient studies, not product packshots.
5. The archive included a `.env.local`. This working copy excluded that file and did not inspect its values. Treat any credentials in the original archive as exposed and rotate/reissue them before launch; see `ENVIRONMENT.md`.
6. Confirm and apply outstanding Supabase migrations to the intended deployment, including the catalogue/admin functions documented in the existing phase report, then test Supabase Auth, Paystack, Cloudinary and Resend against the real account. None of those live services was changed or tested here.

## Intentionally not invented

No delivery promise, minimum order, wholesale price, returns deadline, refund rule, legal privacy promise, certification, customer testimonial or medical benefit has been fabricated. Existing business facts, catalogue data, payment architecture and public contact details are preserved.

## Limitations to resolve

- The hero is a lightweight layered parallax composition, not a full WebGL/Three.js 3D scene; this avoids adding a heavy rendering dependency and preserves a fast mobile fallback.
- There is no existing verified review system, customer-management API, content-management API or business-settings model in the supplied project. Those admin functions were not simulated or represented as real.
- The existing catalogue contains one recorded product size/weight field rather than selectable size variants. The shop and checkout continue to use the actual single product record.
- End-to-end sign-in, customer/admin access, checkout, Paystack verification, contact e-mail delivery and newsletter registration require live service credentials and were not exercised in this sandbox.

## Checks run

- `npm run typecheck` — passed.
- `npm run lint` — passed.
- `npm test -- --run` — 109 passed; 178 database-backed tests skipped because no test database credentials were configured.
- `npm run build` — passed using harmless local public configuration placeholders; no live credentials were embedded.
- Development HTTP smoke check — public home, about, shop, cart, contact, discover, FAQ, wholesale and privacy pages returned HTTP 200. Authenticated account/admin route checks were not considered valid without Supabase credentials.
