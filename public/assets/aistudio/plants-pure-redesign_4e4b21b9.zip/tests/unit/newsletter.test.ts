import { describe, expect, it } from "vitest";
import { newsletterSchema } from "@/lib/newsletter";

describe("newsletter subscription schema", () => {
  it("normalizes the address and requires explicit consent", () => {
    expect(newsletterSchema.parse({ email: "  PERSON@EXAMPLE.COM ", consent: true })).toEqual({ email: "person@example.com", consent: true });
    expect(newsletterSchema.safeParse({ email: "person@example.com", consent: false }).success).toBe(false);
  });

  it("rejects malformed addresses and long values", () => {
    expect(newsletterSchema.safeParse({ email: "not-an-email", consent: true }).success).toBe(false);
    expect(newsletterSchema.safeParse({ email: `${"x".repeat(250)}@example.com`, consent: true }).success).toBe(false);
  });
});
