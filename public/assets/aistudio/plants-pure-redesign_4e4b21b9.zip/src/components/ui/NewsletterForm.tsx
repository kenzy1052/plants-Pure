"use client";

import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { Field, Input } from "@/components/ui/Field";
import { newsletterSchema } from "@/lib/newsletter";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [consent, setConsent] = useState(false);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState<{ kind: "success" | "error"; text: string } | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [consentError, setConsentError] = useState<string | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending) return;
    setMessage(null);
    const parsed = newsletterSchema.safeParse({ email, consent });
    if (!parsed.success) {
      setEmailError(parsed.error.issues.find((issue) => issue.path[0] === "email")?.message ?? null);
      setConsentError(parsed.error.issues.find((issue) => issue.path[0] === "consent")?.message ?? null);
      return;
    }
    setEmailError(null);
    setConsentError(null);
    setPending(true);
    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: parsed.data.email, consent: true, website: "" }),
      });
      const result = await response.json().catch(() => null) as { ok?: boolean; error?: { message?: string } } | null;
      if (response.ok && result?.ok) {
        setMessage({ kind: "success", text: "You’re on the list. Thank you for subscribing." });
        setEmail("");
        setConsent(false);
      } else {
        setMessage({ kind: "error", text: result?.error?.message ?? "We couldn’t complete your subscription. Please try again or contact us." });
      }
    } catch {
      setMessage({ kind: "error", text: "We couldn’t reach the server. Check your connection and try again." });
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={submit} noValidate aria-label="Newsletter subscription" className="newsletter-form">
      <div className="newsletter-form__row">
        <Field id="newsletter-email" label="E-mail address" required error={emailError}>
          {(props) => <Input {...props} type="email" name="email" autoComplete="email" inputMode="email" value={email} onChange={(event) => setEmail(event.target.value)} maxLength={254} placeholder="you@example.com" />}
        </Field>
        <button className="button-arrow" type="submit" disabled={pending} aria-busy={pending}>
          {pending ? "Joining…" : "Subscribe"}
          <ArrowRight className="size-4" aria-hidden="true" />
        </button>
      </div>
      <label className="newsletter-consent">
        <input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} aria-invalid={consentError ? true : undefined} aria-describedby={consentError ? "newsletter-consent-error" : undefined} />
        <span>I agree to receive occasional company and product updates by e-mail.</span>
      </label>
      {consentError && <p id="newsletter-consent-error" role="alert" className="text-caption text-danger">{consentError}</p>}
      {message && <p role={message.kind === "error" ? "alert" : "status"} className={message.kind === "error" ? "text-small text-danger" : "text-small text-success"}>{message.text}</p>}
      <p className="text-caption text-text-inverse-muted">Questions about your details? <a href="mailto:plantsandpure@gmail.com" className="underline underline-offset-4">Contact us</a>.</p>
    </form>
  );
}
