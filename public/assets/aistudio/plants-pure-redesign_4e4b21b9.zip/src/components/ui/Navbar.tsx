"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Menu, Search, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/context/cart-store";
import { Drawer } from "@/components/ui/Drawer";
import { AccountMenu } from "@/components/auth/AccountMenu";
import { Wordmark } from "@/components/ui/Wordmark";
import { Input } from "@/components/ui/Field";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { CONTACT } from "@/lib/constants/business";
import { cn } from "@/lib/utils";

/**
 * Header. Every control here does something real:
 *  - Search opens a sheet whose form is a plain GET to /shop?q=… (works without JS),
 *  - Account goes to /account (the proxy sends signed-out visitors to sign-in),
 *  - Cart opens the cart drawer; the count is the real cart state.
 * Nav links are limited to routes that exist; categories, About, Contact and policy
 * pages arrive with Phase 3 and are listed in docs/DESIGN_SYSTEM.md.
 */
const NAV = [
  { href: "/", label: "Home" },
  { href: "/about", label: "Our story" },
  { href: "/shop", label: "Shop" },
  { href: "/discover", label: "Discover" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const items = useCartStore((s) => s.items);
  const openCart = useCartStore((s) => s.openCart);
  const count = items.reduce((n, i) => n + i.quantity, 0);

  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const [bump, setBump] = useState(false);
  const first = useRef(true);

  // Close panels on navigation (adjusting state during render, not in an effect).
  const [lastPath, setLastPath] = useState(pathname);
  if (lastPath !== pathname) {
    setLastPath(pathname);
    setMenuOpen(false);
    setSearchOpen(false);
  }

  // Brief feedback when the cart count actually changes.
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    setBump(true);
    const t = setTimeout(() => setBump(false), 260);
    return () => clearTimeout(t);
  }, [count]);

  useEffect(() => {
    if (searchOpen) requestAnimationFrame(() => searchRef.current?.focus());
  }, [searchOpen]);

  const icon = "size-5";
  const iconBtn = "relative grid size-11 place-items-center rounded-control text-text transition-colors hover:bg-background-alt";

  return (
    <>
      <header className="sticky top-0 z-(--z-header) border-b border-border bg-background">
        <div className="container-page flex h-(--header-h) items-center gap-2 md:gap-6">
          <button type="button" className={cn(iconBtn, "-ml-2 md:hidden")} onClick={() => setMenuOpen(true)} aria-label="Open menu" aria-haspopup="dialog">
            <Menu className={icon} strokeWidth={1.5} aria-hidden="true" />
          </button>

          <Link href="/" className="shrink-0 rounded-xs" aria-label="Plants & Pure — home">
            <Wordmark />
          </Link>

          <nav aria-label="Primary" className="ml-4 hidden md:block">
            <ul className="flex items-center gap-1">
              {NAV.map((l) => {
                const active = pathname === l.href || pathname.startsWith(`${l.href}/`);
                return (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      aria-current={active ? "page" : undefined}
                      className={cn("eyebrow inline-flex h-11 items-center rounded-control px-3 transition-colors hover:bg-background-alt", active && "underline decoration-2 underline-offset-8 decoration-accent")}
                    >
                      {l.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>

          <div className="ml-auto flex items-center">
            <button type="button" className={iconBtn} onClick={() => setSearchOpen(true)} aria-label="Search products" aria-haspopup="dialog">
              <Search className={icon} strokeWidth={1.5} aria-hidden="true" />
            </button>
            <AccountMenu />
            <ThemeToggle />
            <button type="button" className={iconBtn} onClick={openCart} aria-label={`Open cart, ${count} ${count === 1 ? "item" : "items"}`} aria-haspopup="dialog">
              <ShoppingBag className={icon} strokeWidth={1.5} aria-hidden="true" />
              {count > 0 && (
                <span aria-hidden="true" className={cn("numeral absolute right-0.5 top-0.5 grid min-w-5 place-items-center rounded-pill bg-accent px-1 text-caption font-bold leading-5 text-text", bump && "anim-bump")}>
                  {count}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <Drawer open={menuOpen} onClose={() => setMenuOpen(false)} title="Menu" side="left">
        <nav aria-label="Mobile" className="flex-1 overflow-y-auto px-(--gutter) py-6">
          <ul className="divide-y divide-border border-y border-border">
            {NAV.map((l) => (
              <li key={l.href}>
                <Link href={l.href} aria-current={pathname === l.href ? "page" : undefined} className="flex min-h-14 items-center font-display text-h3">
                  {l.label}
                </Link>
              </li>
            ))}
            <li><Link href="/faqs" className="flex min-h-14 items-center font-display text-h3">FAQs</Link></li>
            <li><Link href="/wholesale" className="flex min-h-14 items-center font-display text-h3">Wholesale</Link></li>
            <li>
              <Link href="/account" className="flex min-h-14 items-center font-display text-h3">
                Account
              </Link>
            </li>
          </ul>
          <div className="mt-8 space-y-1 text-small text-text-secondary">
            <p className="eyebrow text-text-muted">Contact</p>
            <p>
              <a className="underline underline-offset-4" href={`tel:${CONTACT.primaryTel}`}>
                {CONTACT.primaryPhone}
              </a>
            </p>
            <p>
              <a className="underline underline-offset-4" href={`mailto:${CONTACT.email}`}>
                {CONTACT.email}
              </a>
            </p>
            <p>{CONTACT.hours}</p>
          </div>
        </nav>
      </Drawer>

      {/* Search sheet: a normal GET form, so it works without JavaScript too */}
      <Drawer open={searchOpen} onClose={() => setSearchOpen(false)} title="Search" side="top">
        <form
          role="search"
          action="/shop"
          method="get"
          className="container-page flex w-full flex-col gap-3 py-6 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            const q = String(new FormData(e.currentTarget).get("q") ?? "").trim();
            setSearchOpen(false);
            router.push(q ? `/shop?q=${encodeURIComponent(q)}` : "/shop");
          }}
        >
          <label htmlFor="site-search" className="sr-only">
            Search products
          </label>
          <Input id="site-search" ref={searchRef} name="q" type="search" placeholder="Search spices, herbs and oils" autoComplete="off" className="h-14 flex-1 text-body" maxLength={80} />
          <button type="submit" className="inline-flex h-14 items-center justify-center rounded-control bg-action px-8 font-semibold text-text-inverse hover:bg-action-hover">
            Search
          </button>
        </form>
      </Drawer>
    </>
  );
}
