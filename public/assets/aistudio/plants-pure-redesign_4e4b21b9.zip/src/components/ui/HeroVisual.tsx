"use client";

import Image from "next/image";
import { useRef } from "react";

export function HeroVisual() {
  const frame = useRef<HTMLDivElement>(null);
  const last = useRef(0);
  const raf = useRef<number | null>(null);

  function move(event: React.PointerEvent<HTMLDivElement>) {
    if (event.pointerType !== "mouse" || window.matchMedia("(prefers-reduced-motion: reduce)").matches || !frame.current) return;
    const now = performance.now();
    if (now - last.current < 28) return;
    last.current = now;
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;
    if (raf.current !== null) cancelAnimationFrame(raf.current);
    raf.current = requestAnimationFrame(() => {
      frame.current?.style.setProperty("--pointer-x", `${x * 14}px`);
      frame.current?.style.setProperty("--pointer-y", `${y * 12}px`);
    });
  }

  function reset() {
    frame.current?.style.setProperty("--pointer-x", "0px");
    frame.current?.style.setProperty("--pointer-y", "0px");
  }

  return (
    <div ref={frame} className="hero-visual" onPointerMove={move} onPointerLeave={reset} aria-label="Editorial still life of cinnamon, cloves and star anise" role="img">
      <Image src="/images/hero-botanicals.webp" alt="" fill priority sizes="(min-width: 1024px) 54vw, 100vw" className="hero-visual__base" />
      <div className="hero-visual__shade" aria-hidden="true" />
      <Image src="/images/hero-spice-cutout.webp" alt="" width={780} height={975} priority sizes="(min-width: 1024px) 34vw, 78vw" className="hero-visual__cutout" />
      <span className="hero-visual__orbit hero-visual__orbit--one" aria-hidden="true" />
      <span className="hero-visual__orbit hero-visual__orbit--two" aria-hidden="true" />
      <span className="hero-visual__caption" aria-hidden="true">BOTANICAL STUDY · 01</span>
    </div>
  );
}
