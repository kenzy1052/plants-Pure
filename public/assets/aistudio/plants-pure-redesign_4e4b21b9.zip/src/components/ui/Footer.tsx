import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { BUSINESS, COMPANY_NAME, CONTACT } from "@/lib/constants/business";
import { Wordmark } from "@/components/ui/Wordmark";
import { NewsletterForm } from "@/components/ui/NewsletterForm";

export default function Footer() {
  const link = "inline-flex min-h-9 items-center underline-offset-4 hover:underline";
  return (
    <footer data-surface="inverse" className="bg-inverse text-text-inverse">
      <section aria-labelledby="newsletter-title" className="border-b border-text-inverse-muted/25">
        <div className="container-page grid gap-8 py-12 md:grid-cols-12 md:items-end md:py-16">
          <div className="md:col-span-5">
            <p className="eyebrow text-text-inverse-muted">A note from the atelier</p>
            <h2 id="newsletter-title" className="mt-3 font-display text-h2">Stay close to <em>nature.</em></h2>
            <p className="mt-3 max-w-md text-text-inverse-muted">Occasional product and company updates, sent with care.</p>
          </div>
          <div className="md:col-span-6 md:col-start-7"><NewsletterForm /></div>
        </div>
      </section>

      <div className="container-page grid gap-12 py-12 md:grid-cols-12 md:py-16">
        <div className="md:col-span-4">
          <Link href="/" aria-label="Plants & Pure home"><Wordmark className="text-[2.5rem] text-text-inverse [&_em]:text-accent" /></Link>
          <p className="mt-5 max-w-sm text-text-inverse-muted">{BUSINESS.descriptor.value} Founded in {BUSINESS.foundedYear.value}, based in {CONTACT.location}.</p>
          <p className="mt-5 text-small text-text-inverse-muted">A considered catalogue of spices, herbs and natural oils.</p>
        </div>

        <nav aria-label="Explore" className="md:col-span-2 md:col-start-6">
          <p className="eyebrow text-text-inverse-muted">Explore</p>
          <ul className="mt-4 space-y-1">
            {[["/shop", "Shop"], ["/cart", "Shopping cart"], ["/about", "Our story"], ["/discover", "Discover"], ["/faqs", "FAQs"], ["/contact", "Contact"], ["/wholesale", "Wholesale enquiries"], ["/account", "My account"]].map(([href, label]) => <li key={href}><Link href={href} className={link}>{label}</Link></li>)}
          </ul>
        </nav>

        <nav aria-label="Policies" className="md:col-span-2">
          <p className="eyebrow text-text-inverse-muted">Information</p>
          <ul className="mt-4 space-y-1">
            {[["/policies/delivery", "Delivery information"], ["/policies/returns", "Returns & refunds"], ["/policies/privacy", "Privacy notice"], ["/policies/terms", "Terms & conditions"]].map(([href, label]) => <li key={href}><Link href={href} className={link}>{label}</Link></li>)}
          </ul>
        </nav>

        <div className="md:col-span-3">
          <p className="eyebrow text-text-inverse-muted">Contact</p>
          <address className="mt-4 space-y-1 not-italic">
            <p><a className={link} href={`tel:${CONTACT.primaryTel}`}>{CONTACT.primaryPhone}</a></p>
            <p><a className={link} href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></p>
            <p className="text-text-inverse-muted">{CONTACT.hours}</p>
            <p className="text-text-inverse-muted">{CONTACT.location}</p>
          </address>
          <ul className="mt-4 flex gap-4">
            <li><a className={link} href={CONTACT.instagram} target="_blank" rel="noopener noreferrer">Instagram <ArrowUpRight className="ml-1 size-3" aria-hidden="true" /><span className="sr-only"> (opens in a new tab)</span></a></li>
            <li><a className={link} href={CONTACT.facebook} target="_blank" rel="noopener noreferrer">Facebook <ArrowUpRight className="ml-1 size-3" aria-hidden="true" /><span className="sr-only"> (opens in a new tab)</span></a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-text-inverse-muted/25">
        <p className="container-page flex flex-wrap justify-between gap-2 py-5 text-caption text-text-inverse-muted"><span>© {new Date().getFullYear()} {COMPANY_NAME}. All rights reserved.</span><span>Accra, Ghana</span></p>
      </div>
    </footer>
  );
}
