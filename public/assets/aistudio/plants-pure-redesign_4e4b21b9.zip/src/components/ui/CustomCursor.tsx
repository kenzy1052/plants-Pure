"use client";

import { useEffect } from "react";

export function CustomCursor() {
  useEffect(() => {
    const fine = window.matchMedia("(hover: hover) and (pointer: fine)");
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (!fine.matches || reduced.matches) return;

    const dot = document.createElement("span");
    const ring = document.createElement("span");
    dot.className = "cursor-dot";
    ring.className = "cursor-ring";
    dot.setAttribute("aria-hidden", "true");
    ring.setAttribute("aria-hidden", "true");
    document.body.append(dot, ring);
    document.documentElement.classList.add("has-custom-cursor");

    let x = -40;
    let y = -40;
    let rx = x;
    let ry = y;
    let raf = 0;
    let hover = false;
    function move(event: PointerEvent) {
      x = event.clientX;
      y = event.clientY;
      hover = event.target instanceof Element && Boolean(event.target.closest("a, button, input, select, textarea, [role=button]"));
    }
    function animate() {
      rx += (x - rx) * .32;
      ry += (y - ry) * .32;
      dot.style.transform = `translate3d(${x - 3}px, ${y - 3}px, 0)`;
      const dx = x - rx;
      const dy = y - ry;
      ring.style.setProperty("--trail-angle", `${Math.atan2(dy, dx)}rad`);
      ring.style.setProperty("--trail-length", `${Math.min(24, Math.hypot(dx, dy) * .55)}px`);
      ring.style.transform = `translate3d(${rx - 13}px, ${ry - 13}px, 0) scale(${hover ? 1.35 : 1})`;
      raf = requestAnimationFrame(animate);
    }
    window.addEventListener("pointermove", move, { passive: true });
    raf = requestAnimationFrame(animate);

    return () => {
      window.removeEventListener("pointermove", move);
      cancelAnimationFrame(raf);
      document.documentElement.classList.remove("has-custom-cursor");
      dot.remove();
      ring.remove();
    };
  }, []);

  return null;
}
