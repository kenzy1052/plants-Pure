import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/** Small status labels. Use ONLY for facts the system knows (sold out, featured, order status). */
type Tone = "neutral" | "accent" | "success" | "warning" | "danger" | "outline";
const tones: Record<Tone, string> = {
  neutral: "bg-background-alt text-text-secondary",
  accent: "bg-accent text-text",
  success: "bg-success-soft text-success",
  warning: "bg-warning-soft text-warning",
  danger: "bg-danger-soft text-danger",
  outline: "border border-border-strong text-text-secondary",
};

export function Badge({ tone = "neutral", className, children }: { tone?: Tone; className?: string; children: ReactNode }) {
  return <span className={cn("eyebrow inline-flex items-center rounded-pill px-2.5 py-1", tones[tone], className)}>{children}</span>;
}
