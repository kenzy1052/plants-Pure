import Link from "next/link";
import type { ComponentProps } from "react";
import { cn } from "@/lib/utils";

/**
 * Buttons. One ACCENT button per view at most (the main conversion action);
 * everything else is primary (ink), secondary (outline) or quiet.
 * Minimum touch height 44px (md) — sm is 36px and only for dense toolbars.
 */
export type ButtonVariant = "primary" | "accent" | "secondary" | "quiet";
export type ButtonSize = "sm" | "md" | "lg";

const base =
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-semibold tracking-wide rounded-control " +
  "transition-[background-color,color,border-color,transform] duration-(--duration-base) ease-(--ease-standard) " +
  "active:translate-y-px disabled:pointer-events-none aria-disabled:pointer-events-none " +
  "disabled:bg-disabled disabled:text-disabled-text disabled:border-transparent " +
  "aria-disabled:bg-disabled aria-disabled:text-disabled-text aria-disabled:border-transparent";

const variants: Record<ButtonVariant, string> = {
  primary: "bg-action text-text-inverse hover:bg-action-hover border border-transparent",
  accent: "bg-accent text-text hover:bg-accent-hover border border-transparent",
  secondary: "bg-transparent text-text border border-border-strong hover:border-text hover:bg-surface",
  quiet: "bg-transparent text-text underline underline-offset-4 decoration-border-strong hover:decoration-text border border-transparent",
};

const sizes: Record<ButtonSize, string> = {
  sm: "h-9 px-3.5 text-small",
  md: "h-11 px-5 text-small",
  lg: "h-14 px-7 text-body",
};

export function buttonStyles({ variant = "primary", size = "md", className }: { variant?: ButtonVariant; size?: ButtonSize; className?: string } = {}) {
  return cn(base, variants[variant], sizes[size], variant === "quiet" && "px-1", className);
}

type CommonProps = { variant?: ButtonVariant; size?: ButtonSize };

export function Button({ variant, size, className, loading, children, disabled, ...props }: ComponentProps<"button"> & CommonProps & { loading?: boolean }) {
  return (
    <button
      type="button"
      {...props}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={buttonStyles({ variant, size, className })}
    >
      {children}
    </button>
  );
}

export function ButtonLink({ variant, size, className, ...props }: ComponentProps<typeof Link> & CommonProps) {
  return <Link {...props} className={buttonStyles({ variant, size, className })} />;
}
