"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Accessible modal panel built on the native <dialog>:
 *  - showModal() gives a real focus trap, inert page behind it and Escape-to-close,
 *  - focus returns to the opener on close (browser behaviour),
 *  - clicking the backdrop closes it, page scroll is locked while open.
 * `side` picks the edge it slides from; `top` is a full-width search sheet.
 * Closing is instant (no exit animation) by design: it never delays the user.
 */
export function Drawer({
  open,
  onClose,
  title,
  side = "right",
  children,
  className,
  hideTitle,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  side?: "right" | "left" | "top";
  children: ReactNode;
  className?: string;
  hideTitle?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) {
      d.showModal();
      document.documentElement.style.overflow = "hidden";
    }
    if (!open && d.open) d.close();
    return () => {
      document.documentElement.style.overflow = "";
    };
  }, [open]);

  const place = side === "right" ? "ml-auto h-dvh w-[min(28rem,100vw)] anim-panel-right" : side === "left" ? "mr-auto h-dvh w-[min(24rem,100vw)] anim-panel-left" : "mx-0 mb-auto h-auto w-full anim-fade";

  return (
    <dialog
      ref={ref}
      aria-label={title}
      onClose={() => {
        document.documentElement.style.overflow = "";
        onClose();
      }}
      onClick={(e) => {
        if (e.target === ref.current) ref.current?.close(); // backdrop click
      }}
      className={cn(
        "m-0 max-h-none max-w-none bg-surface p-0 text-text shadow-overlay backdrop:bg-overlay backdrop:backdrop-blur-none",
        "open:flex open:flex-col",
        place,
        className,
      )}
    >
      <div className={cn("flex items-center justify-between border-b border-border px-(--gutter) py-4", hideTitle && "justify-end")}>
        {!hideTitle && <h2 className="font-display text-h3">{title}</h2>}
        <button type="button" onClick={() => ref.current?.close()} className="grid size-11 place-items-center rounded-control hover:bg-background-alt" aria-label={`Close ${title.toLowerCase()}`}>
          <X className="size-5" strokeWidth={1.5} aria-hidden="true" />
        </button>
      </div>
      {children}
    </dialog>
  );
}
