"use client";

import { useEffect, useSyncExternalStore } from "react";
import { Moon, Sun } from "lucide-react";

const KEY = "plants-pure-theme";
type Theme = "light" | "dark";
const listeners = new Set<() => void>();

function snapshot(): Theme {
  return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
}
function serverSnapshot(): Theme { return "light"; }
function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
function publish() { listeners.forEach((listener) => listener()); }
function setTheme(theme: Theme) {
  document.documentElement.dataset.theme = theme;
  try { window.localStorage.setItem(KEY, theme); } catch { /* session-only theme if storage is unavailable */ }
  publish();
}

export function ThemeToggle() {
  const theme = useSyncExternalStore(subscribe, snapshot, serverSnapshot);
  useEffect(() => {
    let stored: string | null = null;
    try { stored = window.localStorage.getItem(KEY); } catch { /* keep the default theme */ }
    if (stored === "dark" || stored === "light") {
      document.documentElement.dataset.theme = stored;
      publish();
    }
  }, []);

  function toggle() { setTheme(theme === "light" ? "dark" : "light"); }

  return (
    <button
      type="button"
      onClick={toggle}
      className="grid size-11 place-items-center rounded-control text-text transition-colors hover:bg-background-alt"
      aria-label={`Use ${theme === "light" ? "dark" : "light"} theme`}
      title={`Switch to ${theme === "light" ? "dark" : "light"} theme`}
    >
      {theme === "light" ? <Moon className="size-5" strokeWidth={1.5} aria-hidden="true" /> : <Sun className="size-5" strokeWidth={1.5} aria-hidden="true" />}
    </button>
  );
}
