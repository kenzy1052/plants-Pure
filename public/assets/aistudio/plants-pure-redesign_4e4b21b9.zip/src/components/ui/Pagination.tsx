import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { pageWindow } from "@/lib/catalogue/params";
import { cn } from "@/lib/utils";

/** Server-rendered pagination: plain links (work without JavaScript, crawlable, shareable). */
export function Pagination({ current, pages, hrefFor, className }: { current: number; pages: number; hrefFor: (page: number) => string; className?: string }) {
  if (pages <= 1) return null;
  const item = "inline-flex h-11 min-w-11 items-center justify-center whitespace-nowrap rounded-control px-3 text-small font-semibold numeral transition-colors duration-(--duration-fast)";
  return (
    <nav aria-label="Pagination" className={cn("flex flex-wrap items-center justify-center gap-1", className)}>
      {current > 1 ? (
        <Link href={hrefFor(current - 1)} rel="prev" className={cn(item, "gap-1 border border-border-strong hover:border-text")} aria-label="Previous page">
          <ChevronLeft className="size-4" aria-hidden="true" />
          <span className="sr-only sm:not-sr-only">Previous</span>
        </Link>
      ) : null}
      <ul className="flex items-center gap-1">
        {pageWindow(current, pages).map((n, i) =>
          n === null ? (
            <li key={`gap-${i}`} aria-hidden="true" className="px-1 text-text-muted">
              …
            </li>
          ) : (
            <li key={n}>
              <Link
                href={hrefFor(n)}
                aria-label={`Page ${n}`}
                aria-current={n === current ? "page" : undefined}
                className={cn(item, n === current ? "bg-action text-text-inverse" : "hover:bg-background-alt")}
              >
                {n}
              </Link>
            </li>
          ),
        )}
      </ul>
      {current < pages ? (
        <Link href={hrefFor(current + 1)} rel="next" className={cn(item, "gap-1 border border-border-strong hover:border-text")} aria-label="Next page">
          <span className="sr-only sm:not-sr-only">Next</span>
          <ChevronRight className="size-4" aria-hidden="true" />
        </Link>
      ) : null}
    </nav>
  );
}
