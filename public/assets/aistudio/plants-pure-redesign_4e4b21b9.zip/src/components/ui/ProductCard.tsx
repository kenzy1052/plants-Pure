"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useCartStore } from "@/context/cart-store";
import { Badge } from "@/components/ui/Badge";
import { Price } from "@/components/ui/Price";
import { PRODUCT_PLACEHOLDER } from "@/lib/catalogue/images";
import type { Product } from "@/lib/types";
import { cn } from "@/lib/utils";

/**
 * Product card. The IMAGE is the hero: a 4:5 frame, no border, no shadow at rest.
 *  - The whole card is one link (stretched link on the name); the Add button sits above it.
 *  - Shows only what the database supplies: name, price (+ real compare-at price),
 *    pack weight when present, "Sold out" when stock is 0, "Featured" when flagged.
 *  - Image fit: `cover` for lifestyle photos, `contain` for white-background packshots
 *    (prop `fit`). Missing image -> neutral placeholder, never a stock photo.
 *  - Long names wrap (max 3 lines, clamped) so grid rows stay aligned.
 */
export default function ProductCard({ product, fit = "cover", priority = false, className }: { product: Product; fit?: "cover" | "contain"; priority?: boolean; className?: string }) {
  const addItem = useCartStore((s) => s.addItem);
  const soldOut = (product.stock ?? 0) <= 0;
  const [broken, setBroken] = useState(false);
  const image = broken ? undefined : product.image_urls?.[0];

  return (
    <article className={cn("group relative flex flex-col", className)}>
      <div className="relative aspect-4/5 overflow-hidden bg-background-alt">
        <Image
          src={image || PRODUCT_PLACEHOLDER}
          alt=""
          fill
          priority={priority}
          onError={() => setBroken(true)}
          sizes="(min-width: 1024px) 22vw, (min-width: 640px) 33vw, 50vw"
          className={cn("transition-transform duration-(--duration-slow) ease-(--ease-settle) group-hover:scale-[1.03]", fit === "contain" ? "object-contain p-6" : "object-cover", soldOut && "opacity-60")}
        />
        <div className="absolute left-3 top-3 flex gap-1.5">
          {soldOut && <Badge tone="neutral" className="bg-surface">Sold out</Badge>}
          {!soldOut && product.is_featured && <Badge tone="accent">Featured</Badge>}
        </div>
      </div>

      <div className="mt-4 flex flex-1 flex-col gap-1.5">
        <h3 className="font-display text-product line-clamp-3">
          <Link href={`/product/${product.slug}`} className="after:absolute after:inset-0 after:content-[''] hover:underline underline-offset-4 decoration-1">
            {product.title}
            {/* the image alt is empty on purpose: the name is the accessible label */}
          </Link>
        </h3>
        {product.weight_grams ? <p className="numeral text-small text-text-muted">{product.weight_grams} g</p> : null}
        <Price amount={product.price} compareAt={product.compare_at_price} className="mt-auto pt-1" />
      </div>

      <button
        type="button"
        disabled={soldOut}
        onClick={() => addItem(product, 1)}
        // WCAG 2.5.3: the accessible name must start with the visible text
        aria-label={soldOut ? `Unavailable: ${product.title} is sold out` : `Add to cart: ${product.title}`}
        className={cn(
          "relative z-10 mt-4 h-11 w-full rounded-control border border-border-strong text-small font-semibold transition-colors duration-(--duration-base)",
          "hover:border-action hover:bg-action hover:text-text-inverse active:translate-y-px",
          "disabled:border-transparent disabled:bg-disabled disabled:text-disabled-text disabled:pointer-events-none",
        )}
      >
        {soldOut ? "Unavailable" : "Add to cart"}
      </button>
    </article>
  );
}
