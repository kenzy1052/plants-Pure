import "server-only";
import { getServerEnv } from "@/lib/env/server";

let fetchImpl: typeof fetch = (...args) => fetch(...args);
export function __setNewsletterFetchForTests(fetcher: typeof fetch | undefined) {
  fetchImpl = fetcher ?? ((...args) => fetch(...args));
}

export type NewsletterResult = { ok: true } | { ok: false; reason: "not_configured" | "provider_error" | "network_error" };

/** Adds only explicitly consented addresses to the configured Resend segment. */
export async function subscribeNewsletter(email: string): Promise<NewsletterResult> {
  const env = getServerEnv();
  const segmentId = env.resend.newsletterSegmentId;
  if (!env.resend.apiKey || !segmentId) return { ok: false, reason: "not_configured" };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  try {
    const response = await fetchImpl("https://api.resend.com/contacts", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.resend.apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, unsubscribed: false, segments: [{ id: segmentId }] }),
      signal: controller.signal,
    });
    if (!response.ok) return { ok: false, reason: "provider_error" };
    return { ok: true };
  } catch {
    return { ok: false, reason: "network_error" };
  } finally {
    clearTimeout(timeout);
  }
}
