import { clsx, type ClassValue } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";

export { formatGHS } from "@/lib/money";

/**
 * Our type-scale utilities (text-body, text-small, text-h2 …) are FONT SIZES. Without this,
 * tailwind-merge mistakes them for text colours and silently drops `text-text-inverse`
 * from "text-body text-text-inverse"-style combinations (invisible button labels).
 */
const twMerge = extendTailwindMerge({
  extend: {
    classGroups: {
      "font-size": [{ text: ["display", "h1", "h2", "h3", "product", "lead", "body", "small", "caption"] }],
    },
  },
});

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
