import { z } from "zod";

/** The checkbox is mandatory: this endpoint is a marketing subscription, not a contact form. */
export const newsletterSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid e-mail address.").max(254),
  consent: z.literal(true, { error: "Please confirm you want to receive occasional email updates." }),
  website: z.string().max(200).optional(),
});

export type NewsletterInput = z.infer<typeof newsletterSchema>;
