export interface Product {
  id: string;
  category_id?: string;
  title: string;
  slug: string;
  tagline?: string;
  description: string;
  flavor_notes?: string[];
  culinary_uses?: string;
  ingredients?: string | null;
  price: number;
  compare_at_price?: number | null;
  weight_grams?: number | null;
  stock: number;
  is_featured: boolean;
  /** Validated, displayable image URLs, cover first (derived by the catalogue data layer). */
  image_urls: string[];
  /** Same images with alt text, when the product_images table supplies it. */
  images?: ProductImage[];
  /** Category (name + slug) when the product has one. */
  category?: { name: string; slug: string } | null;
}

export interface ProductImage {
  url: string;
  alt: string | null;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  /** Number of PUBLISHED products in the category (0 when none). */
  productCount: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
