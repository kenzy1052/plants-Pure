/**
 * Money helpers. The store sells in Ghana cedis (GHS). Amounts are exact
 * decimals in the database (numeric(10,2)); Paystack wants integer pesewas.
 * NEVER do arithmetic on floats for money — convert at the edges with these.
 */
export const CURRENCY = "GHS" as const;
export const CURRENCY_SYMBOL = "GH₵";

/** "12.50" | 12.5 → 1250. Throws on anything that is not a valid 2-decimal amount. */
export function toMinorUnits(amount: string | number): number {
  const text = typeof amount === "number" ? amount.toFixed(2) : amount.trim();
  if (typeof amount === "number" && !Number.isFinite(amount)) throw new RangeError("Invalid amount");
  const m = /^(-?)(\d{1,10})(?:\.(\d{1,2}))?$/.exec(text);
  if (!m) throw new RangeError("Invalid amount");
  const [, sign, whole, frac = ""] = m;
  const minor = Number(whole) * 100 + Number(frac.padEnd(2, "0"));
  return sign ? -minor : minor;
}

export function fromMinorUnits(minor: number): string {
  if (!Number.isInteger(minor)) throw new RangeError("Minor units must be an integer");
  const sign = minor < 0 ? "-" : "";
  const abs = Math.abs(minor);
  return `${sign}${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, "0")}`;
}

export function formatGHS(amount: number | string): string {
  const n = typeof amount === "string" ? Number(amount) : amount;
  return `${CURRENCY_SYMBOL} ${(Number.isFinite(n) ? n : 0).toFixed(2)}`;
}
