import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { formatGHS } from "@/lib/money";
import { Badge } from "@/components/ui/Badge";

export const metadata: Metadata = { title: "Order details", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export default async function AccountOrderDetailPage({ params }: Props) {
  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) notFound();
  const supabase = await createSupabaseServerClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect(`/auth/sign-in?next=${encodeURIComponent(`/account/orders/${id}`)}`);
  const { data: order, error: orderError } = await supabase.from("orders").select("id,order_number,payment_status,fulfillment_status,subtotal,delivery_fee,total_amount,currency,created_at,delivery_address,delivery_area").eq("id", id).eq("user_id", auth.user.id).maybeSingle();
  if (orderError || !order) notFound();
  const { data: items, error: itemsError } = await supabase.from("order_items").select("id,product_title,quantity,unit_price,total_price,product_slug").eq("order_id", id).order("created_at", { ascending: true });
  if (itemsError) notFound();
  return <div className="container-page py-12 md:py-16"><Link href="/account/orders" className="text-small font-semibold underline underline-offset-4">← Order history</Link><header className="mt-5 flex flex-wrap items-end justify-between gap-4 border-b border-border pb-6"><div><p className="eyebrow text-text-muted">Order details</p><h1 className="mt-2 text-h2">Order #{order.order_number}</h1><p className="mt-2 text-small text-text-secondary">Placed <time dateTime={order.created_at}>{new Date(order.created_at).toLocaleString("en-GB")}</time></p></div><div className="flex flex-wrap gap-2"><Badge tone={order.payment_status === "paid" ? "success" : "neutral"}>Payment: {order.payment_status}</Badge><Badge tone="neutral">Fulfillment: {order.fulfillment_status.replaceAll("_", " ")}</Badge></div></header>
    <div className="mt-8 grid gap-10 lg:grid-cols-12"><section aria-labelledby="items-heading" className="lg:col-span-7"><h2 id="items-heading" className="font-display text-h3">Items</h2><ul className="mt-4 divide-y divide-border border-y border-border">{(items ?? []).map((item) => <li key={item.id} className="flex flex-wrap justify-between gap-4 py-4"><div><p className="font-semibold">{item.product_slug ? <Link href={`/product/${item.product_slug}`} className="underline underline-offset-4">{item.product_title}</Link> : item.product_title}</p><p className="mt-1 text-caption text-text-muted">Quantity {item.quantity} · {formatGHS(item.unit_price)} each</p></div><p className="numeral font-semibold">{formatGHS(item.total_price)}</p></li>)}</ul><dl className="ml-auto mt-5 max-w-sm space-y-2 text-small"><div className="flex justify-between"><dt>Subtotal</dt><dd className="numeral">{formatGHS(order.subtotal)}</dd></div><div className="flex justify-between"><dt>Delivery</dt><dd className="numeral">{formatGHS(order.delivery_fee)}</dd></div><div className="flex justify-between border-t border-border pt-3 font-semibold"><dt>Total</dt><dd className="numeral">{formatGHS(order.total_amount)}</dd></div></dl></section><aside className="lg:col-span-4 lg:col-start-9"><h2 className="font-display text-h3">Delivery details</h2><p className="mt-3 whitespace-pre-line text-text-secondary">{[order.delivery_address, order.delivery_area].filter(Boolean).join("\n") || "No delivery address recorded."}</p><p className="mt-8 text-small text-text-secondary">Questions about this order? <Link href="/contact" className="font-semibold underline underline-offset-4">Contact us</Link>.</p></aside></div>
  </div>;
}
