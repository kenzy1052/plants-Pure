import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { formatGHS } from "@/lib/money";
import { Badge } from "@/components/ui/Badge";
import { EmptyState } from "@/components/ui/EmptyState";

export const metadata: Metadata = { title: "Order history", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function AccountOrdersPage() {
  const supabase = await createSupabaseServerClient();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/auth/sign-in?next=/account/orders");
  const { data: orders, error } = await supabase.from("orders").select("id,order_number,payment_status,fulfillment_status,total_amount,currency,created_at").eq("user_id", auth.user.id).order("created_at", { ascending: false }).limit(100);
  return <div className="container-page py-12 md:py-16"><p className="eyebrow text-text-muted">My account</p><h1 className="mt-2 text-h2">Order history</h1><Link href="/account" className="mt-4 inline-flex min-h-10 items-center text-small font-semibold underline underline-offset-4">← Account overview</Link>
    {error ? <EmptyState className="mt-8" title="Order history is unavailable right now" tone="error"><p>Please try again later or contact us if you need help with an order.</p></EmptyState> : orders?.length ? <div className="mt-8 overflow-x-auto"><table className="w-full min-w-[38rem] border-collapse text-left text-small"><caption className="sr-only">Your orders</caption><thead><tr className="border-b border-border-strong text-text-muted"><th className="py-3 pr-3">Order</th><th className="px-3 py-3">Payment</th><th className="px-3 py-3">Fulfillment</th><th className="px-3 py-3">Total</th><th className="px-3 py-3">Details</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id} className="border-b border-border"><td className="py-3 pr-3">#{order.order_number}<span className="block text-caption text-text-muted"><time dateTime={order.created_at}>{new Date(order.created_at).toLocaleDateString("en-GB")}</time></span></td><td className="px-3 py-3"><Badge tone={order.payment_status === "paid" ? "success" : "neutral"}>{order.payment_status}</Badge></td><td className="px-3 py-3">{order.fulfillment_status.replaceAll("_", " ")}</td><td className="numeral px-3 py-3">{formatGHS(order.total_amount)}</td><td className="px-3 py-3"><Link href={`/account/orders/${order.id}`} className="underline underline-offset-4">View order</Link></td></tr>)}</tbody></table></div> : <EmptyState className="mt-8" title="No account orders yet" action={<Link href="/shop" className="inline-flex min-h-10 items-center font-semibold underline underline-offset-4">Browse the shop</Link>}><p>Orders placed as a guest are not shown in account history.</p></EmptyState>}
  </div>;
}
