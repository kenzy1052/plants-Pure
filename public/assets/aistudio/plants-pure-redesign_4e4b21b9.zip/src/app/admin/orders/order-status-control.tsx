"use client";

import { useState } from "react";
import { Select } from "@/components/ui/Field";

const statuses = ["unfulfilled", "processing", "dispatched", "delivered", "on_hold"] as const;

export function OrderStatusControl({ id, initial }: { id: string; initial: string }) {
  const [status, setStatus] = useState(initial);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState("");
  async function change(next: string) {
    if (!statuses.includes(next as typeof statuses[number]) || next === status) return;
    setPending(true);
    setMessage("");
    try {
      const response = await fetch(`/api/admin/orders/${id}/status`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fulfillment_status: next }) });
      const result = await response.json().catch(() => null) as { ok?: boolean; error?: { message?: string } } | null;
      if (response.ok && result?.ok) { setStatus(next); setMessage("Fulfillment status updated."); }
      else setMessage(result?.error?.message ?? "Status was not updated.");
    } catch { setMessage("Could not reach the server. Try again."); }
    finally { setPending(false); }
  }
  return <div className="flex flex-wrap items-center gap-3"><label htmlFor="fulfillment-status" className="text-small font-semibold">Fulfillment status</label><Select id="fulfillment-status" value={status} onChange={(event) => void change(event.target.value)} disabled={pending}>{statuses.map((item) => <option key={item} value={item}>{item.replaceAll("_", " ")}</option>)}</Select><span role="status" className="text-caption text-text-muted">{pending ? "Saving…" : message}</span></div>;
}
