import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { listOrders } from "@/lib/admin/orders";
import { formatGHS } from "@/lib/money";
import { Badge } from "@/components/ui/Badge";
import { Input, Select } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { Pagination } from "@/components/ui/Pagination";

type Search = Record<string, string | string[] | undefined>;
const first = (value: string | string[] | undefined) => Array.isArray(value) ? value[0] ?? "" : value ?? "";
const paymentStatuses = ["pending", "paid", "failed", "cancelled", "refunded", "review"];
const fulfillmentStatuses = ["unfulfilled", "processing", "dispatched", "delivered", "cancelled", "on_hold"];

export default async function AdminOrdersPage({ searchParams }: { searchParams: Promise<Search> }) {
  const search = await searchParams;
  const q = first(search.q).trim().slice(0, 80);
  const paymentStatus = paymentStatuses.includes(first(search.payment_status)) ? first(search.payment_status) : "";
  const fulfillmentStatus = fulfillmentStatuses.includes(first(search.fulfillment_status)) ? first(search.fulfillment_status) : "";
  const page = Math.max(1, Number.parseInt(first(search.page), 10) || 1);
  const db = await createSupabaseServerClient();
  const result = await listOrders(db, { q: q || undefined, paymentStatus: paymentStatus || undefined, fulfillmentStatus: fulfillmentStatus || undefined, page, pageSize: 20 });
  const pages = Math.max(1, result.pages);
  const hrefFor = (nextPage: number) => { const params = new URLSearchParams(); if (q) params.set("q", q); if (paymentStatus) params.set("payment_status", paymentStatus); if (fulfillmentStatus) params.set("fulfillment_status", fulfillmentStatus); if (nextPage > 1) params.set("page", String(nextPage)); return `/admin/orders${params.size ? `?${params}` : ""}`; };
  return <div><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="eyebrow text-text-muted">Operations</p><h1 className="mt-2 text-h2">Orders</h1></div><p className="text-small text-text-secondary">{result.total} matching {result.total === 1 ? "order" : "orders"}</p></div>
    <form method="get" role="search" aria-label="Filter orders" className="mt-6 grid gap-3 border-y border-border py-5 sm:grid-cols-[1fr_12rem_12rem_auto] sm:items-end"><div className="flex flex-col gap-1.5"><label htmlFor="order-q" className="text-small font-semibold">Search order or customer</label><Input id="order-q" name="q" defaultValue={q} maxLength={80} /></div><div className="flex flex-col gap-1.5"><label htmlFor="payment" className="text-small font-semibold">Payment</label><Select id="payment" name="payment_status" defaultValue={paymentStatus}><option value="">All</option>{paymentStatuses.map((item) => <option key={item}>{item}</option>)}</Select></div><div className="flex flex-col gap-1.5"><label htmlFor="fulfillment" className="text-small font-semibold">Fulfillment</label><Select id="fulfillment" name="fulfillment_status" defaultValue={fulfillmentStatus}><option value="">All</option>{fulfillmentStatuses.map((item) => <option key={item}>{item.replaceAll("_", " ")}</option>)}</Select></div><Button type="submit" variant="secondary">Filter</Button></form>
    {result.items.length ? <><div className="mt-5 overflow-x-auto"><table className="w-full min-w-[48rem] border-collapse text-left text-small"><caption className="sr-only">Order management list</caption><thead><tr className="border-b border-border-strong text-text-muted"><th className="py-3 pr-3">Order</th><th className="px-3 py-3">Customer</th><th className="px-3 py-3">Payment</th><th className="px-3 py-3">Fulfillment</th><th className="px-3 py-3">Items</th><th className="px-3 py-3 text-right">Total</th></tr></thead><tbody>{result.items.map((order) => <tr key={order.id} className="border-b border-border align-middle"><td className="py-3 pr-3"><Link href={`/admin/orders/${order.id}`} className="font-semibold underline underline-offset-4">#{order.order_number}</Link><span className="block text-caption text-text-muted">{new Date(order.created_at).toLocaleDateString("en-GB")}</span></td><td className="px-3 py-3">{order.customer_name}<span className="block text-caption text-text-muted">{order.customer_email}</span></td><td className="px-3 py-3"><Badge tone={order.payment_status === "paid" ? "success" : order.payment_status === "review" ? "warning" : "neutral"}>{order.payment_status}</Badge></td><td className="px-3 py-3">{order.fulfillment_status.replaceAll("_", " ")}{order.requires_review && <span className="ml-2"><Badge tone="warning">Review</Badge></span>}</td><td className="numeral px-3 py-3">{order.item_count}</td><td className="numeral px-3 py-3 text-right">{formatGHS(order.total_amount)}</td></tr>)}</tbody></table></div><Pagination className="mt-8" current={Math.min(page,pages)} pages={pages} hrefFor={hrefFor} /></> : <EmptyState className="mt-6" title={q || paymentStatus || fulfillmentStatus ? "No orders match those filters" : "No orders yet"} action={(q || paymentStatus || fulfillmentStatus) ? <Link href="/admin/orders" className="underline underline-offset-4">Clear filters</Link> : undefined}>{(q || paymentStatus || fulfillmentStatus) ? "Adjust the search or status filters." : "Orders created through the store will appear here."}</EmptyState>}
  </div>;
}
