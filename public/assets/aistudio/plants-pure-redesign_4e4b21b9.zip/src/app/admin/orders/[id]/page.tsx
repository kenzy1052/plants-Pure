import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getOrder } from "@/lib/admin/orders";
import { formatGHS } from "@/lib/money";
import { Badge } from "@/components/ui/Badge";
import { OrderStatusControl } from "../order-status-control";

export default async function AdminOrderDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) notFound();
  const db = await createSupabaseServerClient();
  const result = await getOrder(db, id).catch(() => null);
  if (!result) notFound();
  const { order, items, payments } = result;
  return <div><Link href="/admin/orders" className="text-small font-semibold underline underline-offset-4">← All orders</Link><header className="mt-5 flex flex-wrap items-end justify-between gap-4 border-b border-border pb-6"><div><p className="eyebrow text-text-muted">Order detail</p><h1 className="mt-2 text-h2">Order #{order.order_number}</h1><p className="mt-2 text-small text-text-secondary">Placed {new Date(order.created_at).toLocaleString("en-GB")}</p></div><div className="flex gap-2"><Badge tone={order.payment_status === "paid" ? "success" : "neutral"}>Payment: {order.payment_status}</Badge>{order.requires_review && <Badge tone="warning">Requires review</Badge>}</div></header>
    <section className="mt-8 grid gap-8 md:grid-cols-12"><div className="md:col-span-7"><h2 className="font-display text-h3">Items</h2><ul className="mt-4 divide-y divide-border border-y border-border">{items.map((item) => <li key={item.id} className="flex justify-between gap-4 py-4"><div><p className="font-semibold">{item.title}</p><p className="mt-1 text-caption text-text-muted">Quantity {item.quantity}{item.weight_grams ? ` · ${item.weight_grams} g` : ""}</p></div><div className="text-right"><p>{formatGHS(item.unit_price)} each</p><p className="numeral mt-1 font-semibold">{formatGHS(item.total_price)}</p></div></li>)}</ul><dl className="ml-auto mt-5 max-w-sm space-y-2 text-small"><div className="flex justify-between"><dt>Subtotal</dt><dd className="numeral">{formatGHS(order.subtotal)}</dd></div><div className="flex justify-between"><dt>Delivery</dt><dd className="numeral">{formatGHS(order.delivery_fee)}</dd></div><div className="flex justify-between border-t border-border pt-3 font-semibold"><dt>Total</dt><dd className="numeral">{formatGHS(order.total_amount)}</dd></div></dl></div>
    <aside className="space-y-7 md:col-span-4 md:col-start-9"><section><h2 className="font-display text-h3">Customer</h2><p className="mt-3">{order.customer_name}</p><p><a className="underline underline-offset-4" href={`mailto:${order.customer_email}`}>{order.customer_email}</a></p>{order.customer_phone && <p className="mt-1"><a className="underline underline-offset-4" href={`tel:${order.customer_phone}`}>{order.customer_phone}</a></p>}</section><section><h2 className="font-display text-h3">Delivery</h2><p className="mt-3">{order.zone_name ?? "No delivery zone"}</p>{order.delivery_address && <p className="mt-2 whitespace-pre-line text-small text-text-secondary">{order.delivery_address}</p>}</section><section className="border-t border-border pt-6"><OrderStatusControl id={order.id} initial={order.fulfillment_status} /></section><section><h2 className="font-display text-h3">Payment record</h2>{payments.length ? <ul className="mt-3 space-y-3">{payments.map((payment) => <li key={payment.id} className="border-t border-border pt-3 text-small"><p className="font-semibold">{payment.status}</p><p className="mt-1 break-all text-text-muted">{payment.reference}</p><p className="mt-1">{formatGHS(payment.amount_minor / 100)} · {payment.channel ?? "Channel not recorded"}</p></li>)}</ul> : <p className="mt-3 text-small text-text-secondary">No payment attempts recorded.</p>}</section></aside></section>
  </div>;
}
