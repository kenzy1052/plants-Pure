import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { listOrders } from "@/lib/admin/orders";
import { formatGHS } from "@/lib/money";
import { Badge } from "@/components/ui/Badge";

export default async function AdminIndex() {
  const db = await createSupabaseServerClient();
  const orders = await listOrders(db, { page: 1, pageSize: 8 });
  const needsReview = orders.items.filter((order) => order.requires_review).length;
  return <div><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="eyebrow text-text-muted">Business overview</p><h1 className="mt-2 text-h2">Admin dashboard</h1></div><Link href="/admin/orders" className="inline-flex min-h-11 items-center bg-action px-4 font-semibold text-text-inverse hover:bg-action-hover">View all orders</Link></div>
    <dl className="mt-8 grid gap-4 sm:grid-cols-3">{[["Total orders", String(orders.total)], ["Paid orders", String(orders.counts.paid ?? 0)], ["Flagged in latest 8", String(needsReview)]].map(([label, value]) => <div key={label} className="border-y border-border py-5"><dt className="eyebrow text-text-muted">{label}</dt><dd className="mt-2 font-display text-h2">{value}</dd></div>)}</dl>
    <section className="mt-12" aria-labelledby="recent-orders"><div className="flex items-center justify-between gap-4"><h2 id="recent-orders" className="font-display text-h3">Recent orders</h2><Link href="/admin/orders" className="text-small font-semibold underline underline-offset-4">Orders workspace</Link></div>
      {orders.items.length ? <div className="mt-5 overflow-x-auto"><table className="w-full min-w-[44rem] border-collapse text-left text-small"><caption className="sr-only">Most recent orders</caption><thead><tr className="border-b border-border-strong text-text-muted"><th className="py-3 pr-3">Order</th><th className="px-3 py-3">Customer</th><th className="px-3 py-3">Payment</th><th className="px-3 py-3">Fulfillment</th><th className="px-3 py-3 text-right">Total</th></tr></thead><tbody>{orders.items.slice(0,6).map((order) => <tr key={order.id} className="border-b border-border"><td className="py-3 pr-3"><Link href={`/admin/orders/${order.id}`} className="font-semibold underline underline-offset-4">#{order.order_number}</Link></td><td className="px-3 py-3">{order.customer_name}</td><td className="px-3 py-3"><Badge tone={order.payment_status === "paid" ? "success" : "neutral"}>{order.payment_status}</Badge></td><td className="px-3 py-3">{order.fulfillment_status.replaceAll("_", " ")}</td><td className="numeral px-3 py-3 text-right">{formatGHS(order.total_amount)}</td></tr>)}</tbody></table></div> : <p className="mt-5 border-y border-border py-8 text-text-secondary">No orders are recorded in the store yet.</p>}
    </section>
  </div>;
}
