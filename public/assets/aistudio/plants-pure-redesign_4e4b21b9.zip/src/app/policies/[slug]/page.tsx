import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { CONTACT } from "@/lib/constants/business";

const policies = {
  delivery: { title: "Delivery information", intro: "Delivery options and fees are shown during checkout when they are configured for your order.", note: "The company has not supplied a complete published delivery policy for this site. For current delivery areas, timing, fees or collection arrangements, contact the team before placing an order." },
  returns: { title: "Returns & refunds", intro: "We want customers to have a clear way to ask about an order or payment.", note: "A business-approved returns and refunds policy was not included with the project materials. Please contact Plants & Pure directly for guidance about a specific order; this page does not create a return window or refund commitment." },
  privacy: { title: "Privacy notice", intro: "The store uses customer information to provide the website, account, checkout and enquiry features requested by customers.", note: "A complete company privacy notice, including contact details for privacy requests, data-retention periods and all relevant legal disclosures, has not been supplied. Please contact the company with questions before submitting personal information. This page is not a substitute for the required approved notice." },
  terms: { title: "Terms & conditions", intro: "Please review the product information and checkout summary before completing a purchase.", note: "Company-approved terms and conditions were not included with the project materials. This page does not establish additional sale, delivery, cancellation or warranty terms. Contact Plants & Pure if you need clarification before ordering." },
} as const;

type Slug = keyof typeof policies;
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  if (!Object.prototype.hasOwnProperty.call(policies, slug)) return { title: "Information" };
  return { title: policies[slug as Slug].title, robots: { index: false, follow: true } };
}

export default async function PolicyPage({ params }: Props) {
  const { slug } = await params;
  if (!Object.prototype.hasOwnProperty.call(policies, slug)) notFound();
  const policy = policies[slug as Slug];
  return <><header className="border-b border-border"><div className="container-page py-14 md:py-20"><p className="eyebrow text-text-muted">Customer information</p><h1 className="mt-4 text-h1">{policy.title}</h1><p className="mt-5 max-w-3xl text-lead text-text-secondary">{policy.intro}</p></div></header><section className="container-page section-space"><div className="max-w-3xl border-l-2 border-accent pl-6"><h2 className="font-display text-h3">Information currently available</h2><p className="mt-4 text-text-secondary">{policy.note}</p><p className="mt-5 text-text-secondary">Contact: <a className="underline underline-offset-4" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a> · <a className="underline underline-offset-4" href={`tel:${CONTACT.primaryTel}`}>{CONTACT.primaryPhone}</a>.</p><Link href="/contact" className="mt-7 inline-flex min-h-11 items-center font-semibold underline underline-offset-4">Contact Plants &amp; Pure</Link></div></section></>;
}
