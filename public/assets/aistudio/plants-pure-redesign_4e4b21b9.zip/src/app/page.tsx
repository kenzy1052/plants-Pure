import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { ButtonLink } from "@/components/ui/Button";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/SectionHeading";
import ProductCard from "@/components/ui/ProductCard";
import { EmptyState } from "@/components/ui/EmptyState";
import { HeroVisual } from "@/components/ui/HeroVisual";
import { BUSINESS, CONTACT } from "@/lib/constants/business";
import { listCategories, listProducts } from "@/lib/catalogue/data";
import { shopHref } from "@/lib/catalogue/params";
import type { Category, Product } from "@/lib/types";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Botanical ingredients, thoughtfully chosen",
  description: "Explore spices, herbs and natural oils from Plants & Pure Limited in Accra, Ghana.",
  alternates: { canonical: "/" },
};

const faqPreview = [
  ["What does Plants & Pure offer?", "The published range includes spices, herbs and natural oils. The live catalogue shows current products and availability."],
  ["How do I place an order?", "Add available items to your cart and continue to checkout. Prices and delivery options are shown before payment."],
  ["Where can I find product details?", "Open a product page to see the details recorded for that item. If an ingredient or other detail is not listed, please ask us."],
];

export default async function HomePage() {
  let categories: Category[] = [];
  let products: Product[] = [];
  let total = 0;
  let failed = false;
  try {
    const [cats, list] = await Promise.all([listCategories(), listProducts({ sort: "featured", pageSize: 4 })]);
    categories = cats.filter((category) => category.productCount > 0);
    products = list.items;
    total = list.total;
  } catch {
    failed = true;
  }

  const categoryArt = ["/images/spice-study.webp", "/images/herb-study.webp", "/images/oil-study.webp"];

  return (
    <>
      <section className="hero-shell min-h-[40rem] border-b border-border md:min-h-[44rem]" aria-labelledby="hero-title">
        <HeroVisual />
        <div className="container-page grid min-h-[40rem] items-center py-14 md:min-h-[44rem] md:py-20">
          <div className="hero-copy max-w-3xl">
            <p className="eyebrow flex items-center gap-3 text-accent-ink"><span className="size-1.5 rounded-full bg-accent" aria-hidden="true" /> The art of natural flavour</p>
            <h1 id="hero-title" className="mt-6 max-w-3xl text-display">Nature, carefully <em className="text-accent-ink">brought to life.</em></h1>
            <p className="mt-7 max-w-xl text-lead text-text-secondary">Spices, herbs and natural oils from Plants &amp; Pure Limited, Accra. Find the ingredients and product details that fit your kitchen.</p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <ButtonLink href="/shop" variant="accent" size="lg">Explore the collection <ArrowRight className="size-4" aria-hidden="true" /></ButtonLink>
              <ButtonLink href="/about" variant="quiet" size="lg">Our story <ArrowUpRight className="size-4" aria-hidden="true" /></ButtonLink>
            </div>
            <div className="mt-12 flex flex-wrap gap-x-8 gap-y-2 border-t border-border pt-4 text-small text-text-secondary">
              <span>Founded {BUSINESS.foundedYear.value}</span><span>{CONTACT.location}</span><span>{BUSINESS.legalName.value}</span>
            </div>
          </div>
        </div>
        <p className="sr-only">The hero photography is an editorial illustration of raw ingredients and not a depiction of a specific packaged product.</p>
      </section>

      <section aria-labelledby="intro-title" className="section-space">
        <div className="container-page grid gap-10 md:grid-cols-12 md:items-center md:gap-8">
          <Reveal className="md:col-span-5">
            <p className="eyebrow text-text-muted">A closer look</p>
            <h2 id="intro-title" className="mt-5 text-h2">Everyday ingredients. <em className="text-accent-ink">A little more considered.</em></h2>
          </Reveal>
          <Reveal delay={100} className="md:col-span-5 md:col-start-8">
            <p className="text-lead text-text-secondary">Plants &amp; Pure is a natural products business in Accra, Ghana, dealing in spices, herbs and natural oils.</p>
            <p className="mt-5 text-text-secondary">Explore the current collection, read the available product information, or speak with the team when you need a detail that is not listed.</p>
            <Link href="/about" className="mt-7 inline-flex min-h-11 items-center gap-2 font-semibold underline underline-offset-4 decoration-border-strong hover:decoration-text">Get to know Plants &amp; Pure <ArrowRight className="size-4" aria-hidden="true" /></Link>
          </Reveal>
        </div>
      </section>

      <section aria-labelledby="categories-title" className="section-space-sm bg-background-alt">
        <div className="container-page">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading index="01" eyebrow="The ingredient shelf" title={<span id="categories-title">Explore by nature</span>} lead="Three published product categories, one live catalogue." />
            <ButtonLink href="/shop" variant="secondary">View the shop</ButtonLink>
          </Reveal>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {BUSINESS.publishedCategories.map((category, index) => {
              const active = categories.find((item) => item.name.toLowerCase() === category.name.toLowerCase());
              return (
                <Link key={category.name} href={active ? shopHref({ category: active.slug }) : "/shop"} className="category-tile group">
                  <Image src={categoryArt[index]} alt="" fill sizes="(min-width: 768px) 31vw, 100vw" className="object-cover" />
                  <div className="category-tile__content">
                    <span className="eyebrow text-white/80">0{index + 1} · Ingredient notes</span>
                    <span className="mt-2 flex items-end justify-between gap-4"><span className="font-display text-h2">{category.name}</span><ArrowUpRight className="mb-2 size-5 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" aria-hidden="true" /></span>
                    <span className="mt-2 block max-w-xs text-small text-white/85">{category.description}</span>
                    {active && <span className="mt-3 block text-caption text-white/75">{active.productCount} {active.productCount === 1 ? "listed product" : "listed products"}</span>}
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section aria-labelledby="collection-title" className="section-space">
        <div className="container-page">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <SectionHeading index="02" eyebrow="From the current catalogue" title={<span id="collection-title">A few to begin with</span>} lead="Product names, images, prices and availability come from the live catalogue." />
            <ButtonLink href="/shop" variant="secondary">All products</ButtonLink>
          </Reveal>
          <div className="mt-10">
            {failed ? <EmptyState title="The collection is taking a moment" tone="error" action={<ButtonLink href="/shop" variant="secondary">Try the shop</ButtonLink>}><p>Please refresh in a moment, or contact us on {CONTACT.primaryPhone}.</p></EmptyState> : products.length === 0 ? <EmptyState title="The online collection is being prepared" action={<ButtonLink href={`mailto:${CONTACT.email}`} variant="secondary">Ask the team</ButtonLink>}><p>Current products will appear here when they are published in the catalogue.</p></EmptyState> : <ul className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4 md:gap-x-6">{products.map((product, index) => <li key={product.id}><ProductCard product={product} priority={index < 4} /></li>)}</ul>}
            {!failed && total > 4 && <p className="mt-10 text-center"><Link href="/shop" className="font-semibold underline underline-offset-4">Explore all {total} products</Link></p>}
          </div>
        </div>
      </section>

      <section aria-labelledby="story-title" className="section-space bg-inverse text-text-inverse" data-surface="inverse">
        <div className="container-page grid gap-10 md:grid-cols-12 md:items-center md:gap-8">
          <Reveal className="md:col-span-5">
            <div className="image-frame aspect-[4/5] max-h-[36rem]">
              <Image src="/images/herb-study.webp" alt="Dried culinary herbs arranged on parchment" fill sizes="(min-width: 768px) 36vw, 90vw" className="object-cover" />
            </div>
          </Reveal>
          <Reveal delay={100} className="md:col-span-6 md:col-start-7">
            <p className="eyebrow text-text-inverse-muted">Our story · Accra, Ghana</p>
            <h2 id="story-title" className="mt-5 text-h2">A wish to offer <em>wholesome,</em> natural products.</h2>
            <p className="mt-6 text-lead text-text-inverse-muted">Plants &amp; Pure began in {BUSINESS.foundedYear.value}. Its published mission speaks of making life more beautiful and healthy, and supporting women who want to build businesses with honesty and integrity.</p>
            <Link href="/about" className="mt-8 inline-flex min-h-11 items-center gap-2 font-semibold underline underline-offset-4 decoration-text-inverse-muted hover:decoration-text-inverse">Read our story <ArrowRight className="size-4" aria-hidden="true" /></Link>
          </Reveal>
        </div>
      </section>

      <section aria-labelledby="care-title" className="section-space">
        <div className="container-page grid gap-10 lg:grid-cols-12 lg:gap-8">
          <Reveal className="lg:col-span-4"><SectionHeading index="03" eyebrow="Good to know" title={<span id="care-title">Clear information, before you decide.</span>} lead="A thoughtful shopping experience should make the details easy to find." /></Reveal>
          <Reveal delay={100} className="lg:col-span-7 lg:col-start-6">
            <ul className="divide-y divide-border border-y border-border">
              {[["Live catalogue", "Browse published products and current availability from the store catalogue."], ["Product by product", "Ingredients, usage notes and other attributes appear only when they are recorded for that item."], ["A clear checkout", "Prices use Ghana cedis. Delivery options and fees are shown at checkout before payment."], ["Secure payment", "Checkout redirects to Paystack; payment status is verified by the server." ]].map(([title, text], index) => <li key={title} className="grid gap-2 py-5 sm:grid-cols-[3rem_1fr]"><span className="eyebrow numeral text-text-muted">0{index + 1}</span><div><h3 className="font-display text-h3">{title}</h3><p className="mt-2 max-w-2xl text-text-secondary">{text}</p></div></li>)}
            </ul>
          </Reveal>
        </div>
      </section>

      <section aria-labelledby="discover-title" className="section-space-sm border-y border-border bg-background-alt">
        <div className="container-page grid gap-8 md:grid-cols-12 md:items-end">
          <Reveal className="md:col-span-5"><SectionHeading index="04" eyebrow="Discover" title={<span id="discover-title">A little more from the ingredient shelf.</span>} lead="Explore practical notes for choosing and using the products in your kitchen." /></Reveal>
          <Reveal delay={100} className="md:col-span-6 md:col-start-7">
            <Link href="/discover" className="group flex min-h-32 items-center justify-between gap-6 border-y border-border py-5"><span><span className="eyebrow text-text-muted">Field notes · 01</span><span className="mt-2 block font-display text-h3">Explore the ingredient notes</span><span className="mt-2 block text-small text-text-secondary">Cooking inspiration and product knowledge, without medical claims.</span></span><ArrowUpRight className="size-5 shrink-0 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" aria-hidden="true" /></Link>
          </Reveal>
        </div>
      </section>

      <section aria-labelledby="wholesale-title" className="section-space">
        <div className="container-page grid gap-8 md:grid-cols-12 md:items-center">
          <div className="md:col-span-7"><p className="eyebrow text-text-muted">For businesses</p><h2 id="wholesale-title" className="mt-4 text-h2">Looking at a larger order?</h2><p className="mt-4 max-w-2xl text-lead text-text-secondary">Tell us what your business needs. The team can confirm availability and terms directly; no volume or delivery commitment is assumed here.</p></div>
          <div className="md:col-span-4 md:col-start-9 md:justify-self-end"><ButtonLink href="/wholesale" variant="primary" size="lg">Business enquiries <ArrowRight className="size-4" aria-hidden="true" /></ButtonLink></div>
        </div>
      </section>

      <section aria-labelledby="faq-preview-title" className="section-space-sm bg-background-alt">
        <div className="container-page grid gap-8 md:grid-cols-12">
          <div className="md:col-span-4"><p className="eyebrow text-text-muted">Before you order</p><h2 id="faq-preview-title" className="mt-4 text-h2">A few answers.</h2><Link href="/faqs" className="mt-5 inline-flex min-h-11 items-center gap-2 font-semibold underline underline-offset-4">All FAQs <ArrowRight className="size-4" aria-hidden="true" /></Link></div>
          <div className="md:col-span-7 md:col-start-6">
            {faqPreview.map(([question, answer]) => <details key={question} className="faq-row"><summary>{question}</summary><p>{answer}</p></details>)}
          </div>
        </div>
      </section>
    </>
  );
}
