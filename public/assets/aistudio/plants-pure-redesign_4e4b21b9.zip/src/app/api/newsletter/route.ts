import { Errors, ok, route } from "@/lib/api/errors";
import { assertSameOrigin, readJson } from "@/lib/api/request";
import { enforceRateLimit } from "@/lib/api/rate-limit";
import { logger } from "@/lib/api/logger";
import { newsletterSchema } from "@/lib/newsletter";
import { subscribeNewsletter } from "@/lib/newsletter-service";

export const dynamic = "force-dynamic";

export const POST = route("newsletter", async (request: Request) => {
  assertSameOrigin(request);
  enforceRateLimit(request, "newsletter", { max: 4, windowMs: 60 * 60_000 });
  const input = await readJson(request, newsletterSchema, 2 * 1024);
  if (!input.consent) throw Errors.badRequest("Please confirm your subscription consent.");
  if (input.website?.trim()) {
    logger.info("newsletter.honeypot_triggered", {});
    return ok({ subscribed: true });
  }

  const result = await subscribeNewsletter(input.email);
  if (result.ok) return ok({ subscribed: true });
  if (result.reason === "not_configured") {
    throw Errors.unavailable("Newsletter sign-up is not available yet. Please contact plantsandpure@gmail.com for updates.");
  }
  logger.warn("newsletter.subscription_failed", { reason: result.reason });
  throw Errors.upstream("We couldn’t complete your subscription. Please try again or contact us.");
});
