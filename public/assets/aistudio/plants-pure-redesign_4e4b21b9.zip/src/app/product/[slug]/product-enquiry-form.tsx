"use client";

import { useRef, useState } from "react";
import { contactSchema } from "@/lib/contact";
import { Field, Input, Textarea } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";

export function ProductEnquiryForm({ productId, productName, weight }: { productId: string; productName: string; weight?: number | null }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [message, setMessage] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent">("idle");
  const [error, setError] = useState<string | null>(null);
  const requestId = useRef("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (state === "sending") return;
    const fullMessage = [`Product: ${productName}`, `Product ID: ${productId}`, `Size or quantity of interest: ${quantity}${weight ? ` (${weight} g each)` : ""}`, `Customer message: ${message || "Please share product details."}`].join("\n");
    const payload = { clientRequestId: requestId.current || (requestId.current = crypto.randomUUID()), name, email, phone, subject: `Product enquiry — ${productName}`, message: fullMessage, website: "" };
    const parsed = contactSchema.safeParse(payload);
    if (!parsed.success) { setError(parsed.error.issues[0]?.message ?? "Please check the form."); return; }
    setError(null);
    setState("sending");
    try {
      const response = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(parsed.data) });
      const result = await response.json().catch(() => null) as { ok?: boolean; error?: { message?: string } } | null;
      if (response.ok && result?.ok) setState("sent");
      else { setError(result?.error?.message ?? "We couldn’t send your enquiry. Please try again."); setState("idle"); }
    } catch { setError("We couldn’t reach the server. Check your connection and try again."); setState("idle"); }
  }

  if (state === "sent") return <div role="status" className="mt-5 border-t border-border pt-5 text-small text-success">Your question about {productName} was sent. We’ll reply to {email}.</div>;

  return (
    <form onSubmit={submit} noValidate aria-label={`Enquire about ${productName}`} className="mt-6 space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field id="product-enquiry-name" label="Full name" required>{(a) => <Input {...a} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} maxLength={120} />}</Field>
        <Field id="product-enquiry-email" label="E-mail" required>{(a) => <Input {...a} type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={254} />}</Field>
        <Field id="product-enquiry-phone" label="Phone (optional)">{(a) => <Input {...a} type="tel" autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={32} />}</Field>
        <Field id="product-enquiry-quantity" label="Quantity or size of interest" required>{(a) => <Input {...a} value={quantity} onChange={(e) => setQuantity(e.target.value)} maxLength={80} />}</Field>
      </div>
      <Field id="product-enquiry-message" label="Message" hint="The product name and catalogue ID are included with your enquiry.">{(a) => <Textarea {...a} rows={4} value={message} onChange={(e) => setMessage(e.target.value)} maxLength={1000} />}</Field>
      {error && <p role="alert" className="text-small text-danger">{error}</p>}
      <Button type="submit" variant="secondary" loading={state === "sending"}>{state === "sending" ? "Sending…" : "Ask about this product"}</Button>
    </form>
  );
}
