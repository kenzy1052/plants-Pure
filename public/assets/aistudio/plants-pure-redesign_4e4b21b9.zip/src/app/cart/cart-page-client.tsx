"use client";

import Image from "next/image";
import Link from "next/link";
import { ShoppingBag, Trash2 } from "lucide-react";
import { useCartStore } from "@/context/cart-store";
import { QuantityStepper } from "@/components/ui/QuantityStepper";
import { ButtonLink } from "@/components/ui/Button";
import { formatGHS } from "@/lib/money";
import { PRODUCT_PLACEHOLDER } from "@/lib/catalogue/images";

export function CartPageClient() {
  const items = useCartStore((state) => state.items);
  const hydrated = useCartStore((state) => state.hydrated);
  const updateQuantity = useCartStore((state) => state.updateQuantity);
  const removeItem = useCartStore((state) => state.removeItem);
  const clearCart = useCartStore((state) => state.clearCart);
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  if (!hydrated) return <div className="container-page py-16" role="status" aria-label="Loading your cart"><p className="eyebrow text-text-muted">Your bag</p><p className="mt-6 h-20 animate-pulse bg-background-alt" /></div>;

  return (
    <div className="container-page py-12 md:py-16">
      <header className="border-b border-border pb-7"><p className="eyebrow text-text-muted">Plants &amp; Pure · Your bag</p><h1 className="mt-3 text-h1">Shopping cart</h1><p className="mt-3 text-lead text-text-secondary">Review your selections before continuing to checkout.</p></header>
      {items.length === 0 ? <div className="flex min-h-80 flex-col items-center justify-center gap-4 py-16 text-center"><ShoppingBag className="size-10 text-text-muted" strokeWidth={1.25} aria-hidden="true" /><h2 className="font-display text-h2">Your cart is empty.</h2><p className="max-w-md text-text-secondary">Browse the live collection and add products to your bag when you’re ready.</p><ButtonLink href="/shop" variant="primary">Explore the collection</ButtonLink></div> : <div className="grid gap-10 py-8 lg:grid-cols-12 lg:gap-12">
        <section className="lg:col-span-8" aria-labelledby="cart-items-heading"><div className="flex items-center justify-between gap-4"><h2 id="cart-items-heading" className="font-display text-h3">Your selections <span className="text-small text-text-muted">({items.length})</span></h2><button type="button" onClick={clearCart} className="min-h-11 text-small text-text-secondary underline underline-offset-4">Clear cart</button></div><ul className="mt-5 divide-y divide-border border-y border-border">{items.map(({ product, quantity }) => <li key={product.id} className="grid gap-4 py-5 sm:grid-cols-[7rem_1fr] sm:gap-6"><Link href={`/product/${product.slug}`} className="relative block aspect-[4/5] w-full max-w-28 overflow-hidden bg-background-alt"><Image src={product.image_urls?.[0] || PRODUCT_PLACEHOLDER} alt={product.images?.[0]?.alt || ""} fill sizes="112px" className="object-cover" /></Link><div className="flex min-w-0 flex-col justify-between gap-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="eyebrow text-text-muted">{product.category?.name ?? "Plants & Pure"}</p><Link href={`/product/${product.slug}`} className="mt-1 inline-block font-display text-h3 underline-offset-4 hover:underline">{product.title}</Link>{product.weight_grams && <p className="mt-1 text-small text-text-secondary">{product.weight_grams} g</p>}</div><p className="numeral font-semibold">{formatGHS(product.price * quantity)}</p></div><div className="flex flex-wrap items-center justify-between gap-4"><div className="flex items-center gap-4"><QuantityStepper value={quantity} onChange={(value) => updateQuantity(product.id, value)} max={Math.max(1, Math.min(100, product.stock ?? 100))} label={`Quantity of ${product.title}`} /><span className="numeral text-small text-text-muted">{formatGHS(product.price)} each</span></div><button type="button" onClick={() => removeItem(product.id)} className="inline-flex min-h-11 items-center gap-2 text-small text-text-secondary hover:text-danger" aria-label={`Remove ${product.title} from cart`}><Trash2 className="size-4" aria-hidden="true" />Remove</button></div></div></li>)}</ul><Link href="/shop" className="mt-5 inline-flex min-h-11 items-center font-semibold underline underline-offset-4">Continue shopping</Link></section>
        <aside className="lg:col-span-4 lg:col-start-9"><div className="bg-background-alt p-5 md:p-6"><h2 className="font-display text-h3">Order summary</h2><div className="mt-5 flex items-baseline justify-between border-t border-border pt-4"><span className="font-semibold">Subtotal</span><span className="numeral font-display text-h3">{formatGHS(subtotal)}</span></div><p className="mt-3 text-small text-text-secondary">Delivery is added at checkout. Final price and stock are recalculated by the store before payment.</p><ButtonLink href="/checkout" variant="accent" size="lg" className="mt-6 w-full">Continue to checkout</ButtonLink><p className="mt-4 text-caption text-text-muted">Checkout is handled securely through the existing Paystack flow.</p></div></aside>
      </div>}
    </div>
  );
}
