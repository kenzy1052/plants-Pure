import type { Metadata } from "next";
import localFont from "next/font/local";
import { Toaster } from "sonner";
import Navbar from "@/components/ui/Navbar";
import Footer from "@/components/ui/Footer";
import { CartHydrator } from "@/components/cart/CartHydrator";
import CartDrawer from "@/components/cart/CartDrawer";
import { CustomCursor } from "@/components/ui/CustomCursor";
import { publicEnv } from "@/lib/env/public";
import "./globals.css";

// Self-hosted (SIL OFL) fonts: no build-time or runtime call to Google.
// Display: Instrument Serif (one weight + italic). UI/body: Hanken Grotesk (variable).
const display = localFont({
  src: [
    { path: "./fonts/instrument-serif-latin-400-normal.woff2", style: "normal", weight: "400" },
    { path: "./fonts/instrument-serif-latin-400-italic.woff2", style: "italic", weight: "400" },
  ],
  variable: "--font-display-loaded",
  display: "swap",
  adjustFontFallback: "Times New Roman",
});

const ui = localFont({
  src: [{ path: "./fonts/hanken-grotesk-latin-wght-normal.woff2", style: "normal", weight: "100 900" }],
  variable: "--font-ui-loaded",
  display: "swap",
  adjustFontFallback: "Arial",
});

export const metadata: Metadata = {
  metadataBase: new URL(publicEnv.appUrl),
  title: { default: "Plants & Pure | Natural Spices, Herbs & Oils from Accra, Ghana", template: "%s | Plants & Pure" },
  description: "Plants & Pure Limited: natural herbal spices, herbs and oils from Accra, Ghana.",
  openGraph: { siteName: "Plants & Pure", locale: "en_GH", type: "website" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${ui.variable}`}>
      <body className="flex min-h-dvh flex-col">
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <Navbar />
        <main id="main" tabIndex={-1} className="flex-1 focus:outline-none">
          {children}
        </main>
        <Footer />
        <CartHydrator />
        <CartDrawer />
        <CustomCursor />
        <Toaster
          position="bottom-center"
          offset={16}
          toastOptions={{ duration: 3500 }}
          style={
            {
              "--normal-bg": "var(--p-card)",
              "--normal-text": "var(--p-ink)",
              "--normal-border": "var(--p-rule-strong)",
              "--border-radius": "4px",
              fontFamily: "var(--font-sans)",
            } as React.CSSProperties
          }
        />
      </body>
    </html>
  );
}
