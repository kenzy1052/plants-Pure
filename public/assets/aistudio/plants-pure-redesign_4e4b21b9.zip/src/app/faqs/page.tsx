import type { Metadata } from "next";
import Link from "next/link";
import { CONTACT } from "@/lib/constants/business";

export const metadata: Metadata = { title: "Frequently asked questions", description: "Answers about Plants & Pure products, ordering, payment and contact.", alternates: { canonical: "/faqs" } };

const groups = [
  { title: "The collection", questions: [
    ["What products does Plants & Pure offer?", "The published categories are spices, herbs and natural oils. Current individual products appear in the live shop catalogue."],
    ["What sizes are available?", "Each product page shows the weight or other attributes recorded for that item. The current catalogue does not offer selectable size variants."],
    ["Where can I find ingredients and usage information?", "Product pages display ingredients, culinary use and other details when those details are available in the catalogue. If something is not listed, please ask us before ordering."],
    ["How are products packaged and stored?", "Product-specific packaging and storage details are not consistently published here. Please check the product information or contact the team for the item you have in mind."],
  ] },
  { title: "Orders & payment", questions: [
    ["How do I place an order?", "Add an available product to your cart and continue to checkout. The website shows the delivery options and fees available to your order before payment."],
    ["Which payment methods are available?", "Online payment is handled through Paystack's hosted checkout. Available methods are shown in that payment flow."],
    ["Do you deliver?", "Delivery options are configured in the store and appear at checkout when available. If none are listed, please contact us to ask about current arrangements."],
    ["Can I order in bulk?", "Send a business enquiry through our wholesale form. Availability, pricing and terms are confirmed directly; submitting the form is not a purchase commitment."],
  ] },
  { title: "Contact & support", questions: [
    ["How can I contact Plants & Pure?", `Call ${CONTACT.primaryPhone} or e-mail ${CONTACT.email}. The published business hours are ${CONTACT.hours}.`],
    ["Do I need an account to order?", "Guest checkout is available. An account is optional and is used for your profile and order-related access."],
  ] },
];

export default function FAQsPage() {
  return <><header className="border-b border-border"><div className="container-page py-14 md:py-20"><p className="eyebrow text-text-muted">Help &amp; information</p><h1 className="mt-4 text-h1">Frequently asked questions.</h1><p className="mt-4 max-w-2xl text-lead text-text-secondary">Clear answers based on current company information and the way the store works today.</p></div></header><div className="container-page section-space"><div className="grid gap-14 md:grid-cols-12">{groups.map((group, index) => <section key={group.title} aria-labelledby={`faq-group-${index}`} className="md:col-span-8 md:col-start-5"><h2 id={`faq-group-${index}`} className="eyebrow mb-4 text-text-muted">{group.title}</h2>{group.questions.map(([question, answer]) => <details key={question} className="faq-row"><summary>{question}</summary><p>{answer}</p></details>)}</section>)}<aside className="md:col-span-3 md:col-start-1 md:row-start-1"><p className="font-display text-h3">Still have a question?</p><p className="mt-3 text-text-secondary">Ask us about a specific product or order and we’ll point you to the information available.</p><Link href="/contact" className="mt-5 inline-flex min-h-11 items-center font-semibold underline underline-offset-4">Contact the team</Link></aside></div></div></>;
}
