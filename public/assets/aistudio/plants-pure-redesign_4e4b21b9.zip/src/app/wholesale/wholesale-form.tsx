"use client";

import { useRef, useState } from "react";
import { contactSchema } from "@/lib/contact";
import { Field, Input, Select, Textarea } from "@/components/ui/Field";
import { Button } from "@/components/ui/Button";

const categories = ["Spices", "Herbs", "Natural oils", "More than one category", "Not sure yet"];
const enquiryTypes = ["Wholesale supply", "Bulk purchasing", "Retail partnership", "Food service", "Other business enquiry"];
const volumes = ["Under 10 units", "10–49 units", "50–199 units", "200+ units", "To be discussed"];

type Values = { name: string; business: string; email: string; phone: string; location: string; enquiryType: string; category: string; products: string; volume: string; contactMethod: string; message: string };

export function WholesaleForm() {
  const [values, setValues] = useState<Values>({ name: "", business: "", email: "", phone: "", location: "", enquiryType: "", category: "", products: "", volume: "", contactMethod: "", message: "" });
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [error, setError] = useState<string | null>(null);
  const requestId = useRef("");

  function update(key: keyof Values) {
    return (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setValues((current) => ({ ...current, [key]: event.target.value }));
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === "sending") return;
    setError(null);
    const message = [
      `Business or organization: ${values.business}`,
      `Business location: ${values.location}`,
      `Enquiry type: ${values.enquiryType}`,
      `Product category: ${values.category}`,
      `Products of interest: ${values.products || "Not specified"}`,
      `Estimated order volume: ${values.volume}`,
      `Preferred contact method: ${values.contactMethod}`,
      `Additional message: ${values.message || "None"}`,
    ].join("\n");
    const payload = {
      clientRequestId: requestId.current || (requestId.current = crypto.randomUUID()),
      name: values.name,
      email: values.email,
      phone: values.phone,
      subject: `Wholesale enquiry — ${values.enquiryType}`,
      message,
      website: "",
    };
    const parsed = contactSchema.safeParse(payload);
    if (!parsed.success) {
      setError(parsed.error.issues[0]?.message ?? "Please check the required fields.");
      return;
    }
    setStatus("sending");
    try {
      const response = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(parsed.data) });
      const result = await response.json().catch(() => null) as { ok?: boolean; error?: { message?: string } } | null;
      if (response.ok && result?.ok) {
        setStatus("sent");
      } else {
        setError(result?.error?.message ?? "We couldn’t send your enquiry. Please try again or contact us directly.");
        setStatus("idle");
      }
    } catch {
      setError("We couldn’t reach the server. Check your connection and try again.");
      setStatus("idle");
    }
  }

  if (status === "sent") return <div role="status" className="border-y border-border py-8"><p className="eyebrow text-success">Enquiry sent</p><h2 className="mt-3 font-display text-h3">Thank you, {values.name.split(" ")[0]}.</h2><p className="mt-2 text-text-secondary">We received your business enquiry and will reply to {values.email}. Availability and terms will be confirmed directly.</p></div>;

  return (
    <form onSubmit={submit} noValidate aria-label="Wholesale and bulk enquiry" className="space-y-6">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field id="wholesale-name" label="Full name" required>{(a) => <Input {...a} value={values.name} onChange={update("name")} autoComplete="name" maxLength={120} />}</Field>
        <Field id="wholesale-business" label="Business or organization" required>{(a) => <Input {...a} value={values.business} onChange={update("business")} autoComplete="organization" maxLength={160} required />}</Field>
        <Field id="wholesale-email" label="E-mail" required>{(a) => <Input {...a} type="email" value={values.email} onChange={update("email")} autoComplete="email" maxLength={254} required />}</Field>
        <Field id="wholesale-phone" label="Phone number" required>{(a) => <Input {...a} type="tel" value={values.phone} onChange={update("phone")} autoComplete="tel" inputMode="tel" maxLength={32} required />}</Field>
        <Field id="wholesale-location" label="Business location" required>{(a) => <Input {...a} value={values.location} onChange={update("location")} autoComplete="address-level2" maxLength={140} required />}</Field>
        <Field id="wholesale-type" label="Enquiry type" required>{(a) => <Select {...a} value={values.enquiryType} onChange={update("enquiryType")} required><option value="">Choose an enquiry type</option>{enquiryTypes.map((item) => <option key={item}>{item}</option>)}</Select>}</Field>
        <Field id="wholesale-category" label="Product category" required>{(a) => <Select {...a} value={values.category} onChange={update("category")} required><option value="">Choose a category</option>{categories.map((item) => <option key={item}>{item}</option>)}</Select>}</Field>
        <Field id="wholesale-volume" label="Estimated order volume" required>{(a) => <Select {...a} value={values.volume} onChange={update("volume")} required><option value="">Select a range</option>{volumes.map((item) => <option key={item}>{item}</option>)}</Select>}</Field>
        <Field id="wholesale-products" label="Specific products of interest" hint="Names or product links, if known." className="sm:col-span-2">{(a) => <Input {...a} value={values.products} onChange={update("products")} maxLength={320} />}</Field>
        <Field id="wholesale-contact-method" label="Preferred contact method" required>{(a) => <Select {...a} value={values.contactMethod} onChange={update("contactMethod")} required><option value="">Choose a method</option><option>E-mail</option><option>Phone</option></Select>}</Field>
        <Field id="wholesale-message" label="Additional message" hint="Share context that will help us understand your requirements." className="sm:col-span-2">{(a) => <Textarea {...a} rows={5} value={values.message} onChange={update("message")} maxLength={1000} />}</Field>
      </div>
      {error && <p role="alert" className="border-l-2 border-danger pl-3 text-small text-danger">{error}</p>}
      <Button type="submit" variant="primary" size="lg" loading={status === "sending"}>{status === "sending" ? "Sending enquiry…" : "Send business enquiry"}</Button>
    </form>
  );
}
