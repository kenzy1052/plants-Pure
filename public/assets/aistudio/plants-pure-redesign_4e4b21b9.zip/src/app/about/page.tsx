import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { ButtonLink } from "@/components/ui/Button";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/ui/Reveal";
import { BUSINESS, CONTACT } from "@/lib/constants/business";

export const metadata: Metadata = {
  title: "Our story",
  description: "Meet Plants & Pure Limited, a natural products business founded in 2020 and based in Accra, Ghana.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  const { story, publishedCategories } = BUSINESS;
  return (
    <>
      <header className="border-b border-border">
        <div className="container-page grid gap-8 py-14 md:grid-cols-12 md:items-end md:py-20">
          <div className="md:col-span-8"><p className="eyebrow text-text-muted">Plants &amp; Pure Limited · Since {BUSINESS.foundedYear.value}</p><h1 className="mt-5 text-h1">A wish to offer <em className="text-accent-ink">wholesome,</em> natural products.</h1></div>
          <p className="max-w-sm text-lead text-text-secondary md:col-span-3 md:col-start-10">A natural products business based in {CONTACT.location}, with a published range of spices, herbs and natural oils.</p>
        </div>
      </header>

      <section aria-labelledby="story-title" className="section-space">
        <div className="container-page grid gap-10 md:grid-cols-12 md:items-center md:gap-8">
          <Reveal className="md:col-span-6"><div className="image-frame aspect-[4/3]"><Image src="/images/spice-study.webp" alt="Raw spices arranged as an editorial ingredient study" fill sizes="(min-width: 768px) 48vw, 100vw" className="object-cover" /></div></Reveal>
          <Reveal delay={100} className="md:col-span-5 md:col-start-8">
            <p className="eyebrow text-text-muted">Our beginning · {BUSINESS.foundedYear.value}</p><h2 id="story-title" className="mt-4 text-h2">A company built around natural ingredients.</h2>
            <p className="mt-5 text-lead text-text-secondary">{story.origin}</p>
            <p className="mt-4 text-text-secondary">The company describes itself as a dealer in natural herbal spices from natural ingredients. Its published product categories are spices, herbs and natural oils.</p>
          </Reveal>
        </div>
      </section>

      <section data-surface="inverse" aria-labelledby="mission-title" className="section-space bg-inverse text-text-inverse">
        <div className="container-page grid gap-10 md:grid-cols-12 md:gap-8">
          <Reveal className="md:col-span-4"><SectionHeading inverse index="01" eyebrow="The mission" title={<span id="mission-title">What we set out to do</span>} /></Reveal>
          <Reveal delay={100} className="md:col-span-7 md:col-start-6"><ol className="divide-y divide-text-inverse-muted/30 border-y border-text-inverse-muted/30">{story.mission.map((item, index) => <li key={item} className="grid grid-cols-[3rem_1fr] gap-4 py-6"><span className="eyebrow numeral text-text-inverse-muted">0{index + 1}</span><span className="font-display text-h3 leading-snug">{item}</span></li>)}</ol></Reveal>
        </div>
      </section>

      <section aria-labelledby="offer-title" className="section-space">
        <div className="container-page grid gap-10 md:grid-cols-12 md:gap-8">
          <Reveal className="md:col-span-4"><SectionHeading index="02" eyebrow="What we offer" title={<span id="offer-title">A focused range of botanicals.</span>} lead="These category descriptions are drawn from the company's published site." /></Reveal>
          <Reveal delay={100} className="md:col-span-7 md:col-start-6"><ol className="divide-y divide-border border-y border-border">{publishedCategories.map((category, index) => <li key={category.name} className="grid grid-cols-[3rem_1fr] gap-4 py-6"><span className="eyebrow numeral text-text-muted">0{index + 1}</span><div><h3 className="font-display text-h3">{category.name}</h3><p className="mt-2 max-w-xl text-text-secondary">{category.description}</p></div></li>)}</ol><ButtonLink href="/shop" className="mt-7" variant="secondary">Discover the collection</ButtonLink></Reveal>
        </div>
      </section>

      <section aria-labelledby="approach-title" className="section-space-sm bg-background-alt">
        <div className="container-page grid gap-8 md:grid-cols-12">
          <div className="md:col-span-4"><p className="eyebrow text-text-muted">A considered experience</p><h2 id="approach-title" className="mt-4 text-h2">Make the details easy to find.</h2></div>
          <div className="md:col-span-7 md:col-start-6"><p className="text-lead text-text-secondary">We present the product information that is available in the catalogue and make it simple to ask when you need more.</p><ul className="mt-6 divide-y divide-border border-y border-border">{["Prices and availability are taken from the live catalogue.", "Product ingredients, usage notes and attributes appear when they are recorded.", "Checkout shows delivery options and fees before a payment is started.", "Questions can be sent through a form or by using our published contact details."].map((item, index) => <li key={item} className="grid grid-cols-[2.5rem_1fr] gap-3 py-4"><span className="eyebrow numeral text-text-muted">0{index + 1}</span><span className="text-text-secondary">{item}</span></li>)}</ul></div>
        </div>
      </section>

      <section aria-label="Contact Plants & Pure" className="section-space-sm"><div className="container-page flex flex-col gap-5 md:flex-row md:items-end md:justify-between"><p className="max-w-2xl font-display text-h3">Want to ask about the company or a product? <Link href="/contact" className="underline underline-offset-4">Talk to us <ArrowRight className="inline size-4" aria-hidden="true" /></Link>.</p><p className="text-small text-text-secondary">{CONTACT.hours} · {CONTACT.location}</p></div></section>
    </>
  );
}
