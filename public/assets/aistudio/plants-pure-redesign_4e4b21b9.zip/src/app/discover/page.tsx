import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export const metadata: Metadata = { title: "Discover", description: "Ingredient notes and cooking inspiration from Plants & Pure.", alternates: { canonical: "/discover" } };

const notes = [
  { number: "01", title: "A closer look at spices", image: "/images/spice-study.webp", alt: "Cinnamon, cloves and star anise arranged on warm stone", text: "Use the product catalogue to explore the spices currently listed. Product pages carry the available descriptions, attributes and culinary-use notes for each item." },
  { number: "02", title: "The herb shelf", image: "/images/herb-study.webp", alt: "Dried herbs arranged in a botanical study", text: "Start with the herb category, then check the specific product page for recorded ingredients and usage information. Details can vary by item." },
  { number: "03", title: "Natural oils, considered", image: "/images/oil-study.webp", alt: "Golden oil catching the light beside seeds and a wooden spoon", text: "Browse the natural oils currently available and review each product's own description. For intended use or ingredients not listed, ask the team before purchasing." },
];

export default function DiscoverPage() {
  return (
    <>
      <header className="border-b border-border"><div className="container-page grid gap-8 py-14 md:grid-cols-12 md:items-end md:py-20"><div className="md:col-span-8"><p className="eyebrow text-text-muted">Discover · Field notes</p><h1 className="mt-4 text-h1">A little more from the <em className="text-accent-ink">ingredient shelf.</em></h1></div><p className="max-w-sm text-lead text-text-secondary md:col-span-3 md:col-start-10">Cooking inspiration and product knowledge, grounded in what the catalogue actually tells us.</p></div></header>
      <div className="container-page section-space"><div className="grid gap-12">{notes.map((note, index) => <article key={note.number} className="grid gap-7 border-b border-border pb-12 md:grid-cols-12 md:items-center md:gap-8"><div className={`md:col-span-5 ${index % 2 ? "md:col-start-8 md:row-start-1" : ""}`}><div className="image-frame aspect-[4/3]"><Image src={note.image} alt={note.alt} fill sizes="(min-width: 768px) 40vw, 100vw" className="object-cover" /></div></div><div className={`md:col-span-6 ${index % 2 ? "md:col-start-1 md:row-start-1" : "md:col-start-7"}`}><p className="eyebrow numeral text-text-muted">FIELD NOTE · {note.number}</p><h2 className="mt-3 text-h2">{note.title}</h2><p className="mt-4 max-w-xl text-lead text-text-secondary">{note.text}</p><Link href="/shop" className="mt-6 inline-flex min-h-11 items-center gap-2 font-semibold underline underline-offset-4">Explore the shop <ArrowUpRight className="size-4" aria-hidden="true" /></Link></div></article>)}</div><p className="mt-8 max-w-3xl text-small text-text-muted">These notes are general culinary inspiration, not health advice or guarantees about a specific product. Refer to the individual catalogue listing and contact Plants &amp; Pure with product-specific questions.</p></div>
    </>
  );
}
