import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  test: {
    include: ["tests/**/*.test.ts"],
    exclude: ["tests/live/**", "node_modules/**"], // live checks run only through `npm run test:live`
    environment: "node",
    testTimeout: 30_000,
    hookTimeout: 90_000,
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
      // `server-only` throws outside a React Server Components build; in unit
      // tests we want the module to load, so point it at an empty stub.
      "server-only": path.resolve(__dirname, "tests/stubs/server-only.ts"),
    },
  },
});
